import Fakerator from 'fakerator';
const faker = Fakerator('es-ES');

const FAKE_SEARCH_ID = faker.misc.uuid();
const FAKE_BALANCE_ID = faker.misc.uuid();

export { FAKE_SEARCH_ID, FAKE_BALANCE_ID };
