import BalancesCacheModel from '../src/models/BalancesCacheModel';
import UtilityModel from '../src/models/UtilityModel';
import getBalancesUsecaseAction from '../src/usecases/balances/getBalancesUsecaseAction';
import saveBalancesUsecaseAction from '../src/usecases/cache/saveBalancesUsecaseAction';
import getUtilityUsecaseAction from '../src/usecases/utilities/getUtilityUsecaseAction';
import { getFakeUtilityByCuit } from './makeFakeUtility';
import * as microServicesBalancesIndex from '../src/gateways/microservices/balances/index';
import { logError } from '../src/logger';
import { LITORAL_GAS_CUIT } from './utilitiesCuitTest';
import { BalancesRequestValidator } from '../src/entities';
import parseBalances from '../src/adapters/parseBalances';
import { fakeDataCache } from './makeFakeDataCache';
import { getFakeBalanceResponseApiByCuit } from './mocks/gateways/microservices/balances/makeFakeResponseCallApiBalance';

//mock
let mockUtiliyModel = jest.mock('../src/models/UtilityModel');
let mockBalancesCacheModel = jest.mock('../src/models/BalancesCacheModel');

//instances
//getUtilityUsecaseAction
const utilityModel = new UtilityModel();
let parameters = {
  utilityModel: utilityModel,
  logError,
};
const fakeUtility = getFakeUtilityByCuit(LITORAL_GAS_CUIT);
mockUtiliyModel.spyOn(utilityModel, 'findByCUIT').mockImplementation(() => fakeUtility);
const getUtility = getUtilityUsecaseAction(parameters);

//getBalancesUsecaseAction
const fakeResponseApi = getFakeBalanceResponseApiByCuit(LITORAL_GAS_CUIT);
const fakeGetBalances = jest
  .spyOn(microServicesBalancesIndex, 'default')
  .mockImplementation(() => fakeResponseApi);

parameters = {
  Validator: BalancesRequestValidator,
  getBalances: microServicesBalancesIndex.default,
};
const getBalances = getBalancesUsecaseAction(parameters);

//saveBalancesUsecaseAction
const balancesCacheModel = new BalancesCacheModel();
parameters = {
  balancesCacheModel: balancesCacheModel,
};
mockBalancesCacheModel.spyOn(balancesCacheModel, 'save').mockImplementation(() => fakeDataCache);
const saveBalances = saveBalancesUsecaseAction(parameters);

const parametersGetBalancesControllerAction = {
  getUtility,
  getBalances,
  parseBalances,
  saveBalances,
};

export { mockUtiliyModel, parametersGetBalancesControllerAction };
