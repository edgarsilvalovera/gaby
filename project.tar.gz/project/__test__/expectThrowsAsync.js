export const expectCodeThrowsAsync = async (method, errorMessage) => {
  try {
    await method();
  } catch (error) {
    expect(error.code).toEqual(errorMessage);
  }
};

export const expectErrorBeInstanceOfAsync = async (method, error) => {
  try {
    await method;
  } catch (err) {
    expect(err).toBeInstanceOf(error);
    return err;
  }
};
