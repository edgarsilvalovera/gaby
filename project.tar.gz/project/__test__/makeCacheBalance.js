import balanceModel from '../src/models/BalancesCacheModel';
import { getFakeResponseReadRedisByCuit } from './mocks/models/redis/makeFakeResponseReadRedis';
import * as uuid from 'uuid';
import { LITORAL_GAS_CUIT } from './utilitiesCuitTest';

export const cacheBalance = async () => {
  const searchId = uuid.v4();

  const response = getFakeResponseReadRedisByCuit(LITORAL_GAS_CUIT, true);

  await new balanceModel().save(searchId, JSON.parse(response));

  return searchId;
};
