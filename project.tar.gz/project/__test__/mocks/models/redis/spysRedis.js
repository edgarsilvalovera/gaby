import { getMockBalancesCacheModel } from '../balanceCache/mocksBalanceCache';

const mockBalancesCacheModel = getMockBalancesCacheModel();

const spyReadRedis = jest
  .mock('../../../../src/models/BalancesCacheModel')
  .spyOn(mockBalancesCacheModel, 'read');

const spySaveRedis = jest
  .mock('../../../../src/models/BalancesCacheModel')
  .spyOn(mockBalancesCacheModel, 'save');

export { spyReadRedis, spySaveRedis };
