import Fakerator from 'fakerator';
import EMU from '../../../../src/constants/emu';
import { getNameUtilityByCuit, LITORAL_GAS_CUIT } from '../../../utilitiesCuitTest';
import { getFakeResponseCallApiBalanceByCuit } from '../../gateways/microservices/balances/makeFakeResponseCallApiBalance';
import { makeFakeBalance } from '../../gateways/tapi/balances/makeFakeBalance';
import { FAKE_BALANCE_ID, FAKE_SEARCH_ID } from '../../../utilFakeId';
import { ORIGIN } from '../../../../src/constants/balanceOrigin';

const faker = Fakerator('es-ES');

let mainTx = faker.misc.uuid();

const getFakeResponseBalance = ({ cuit, isTapiRequest = false }) => {
  const utility = getNameUtilityByCuit(cuit) || 'utility';
  return {
    parsedResponse: {
      mainTx: mainTx,
      tx: '',
      balancesInfo: {
        utility,
        searchId: FAKE_SEARCH_ID,
        paymentDocument: undefined,
        customerName: null,
        customerAddress: null,
        balances: [
          {
            balanceId: FAKE_BALANCE_ID,
            amount: 10,
            isPayable: true,
            concept: 'total',
            message: null,
            dueDate: null,
            index: 0,
          },
        ],
      },
    },
    originalResponse: isTapiRequest
      ? { ...makeFakeBalance(), utility }
      : {
          ...getFakeResponseCallApiBalanceByCuit(cuit),
          utility,
        },
  };
};

const fakeResponseBalance = getFakeResponseBalance({ cuit: LITORAL_GAS_CUIT });

const {
  qrTypes: { iep },
} = EMU;

const getFakeResponseReadRedisByCuit = (cuit, isTapiRequest = false) => {
  let balance = getFakeResponseBalance({ cuit, isTapiRequest });

  //asign balance id to original response
  if (!isTapiRequest)
    balance.originalResponse.balances = balance.originalResponse.balances.map((b) => ({
      ...b,
      balanceId: FAKE_BALANCE_ID,
    }));

  const fakeData = {
    searchId: balance.parsedResponse.balancesInfo.searchId,
    request: {
      params: {
        cuit,
        qrType: iep,
      },
      baseUrl: 'http://localhost:8080',
    },
    response: balance.originalResponse,
    origin: isTapiRequest ? ORIGIN.TAPI : ORIGIN.UTILITIES,
  };

  return JSON.stringify(fakeData);
};

export { getFakeResponseBalance, getFakeResponseReadRedisByCuit, fakeResponseBalance };
