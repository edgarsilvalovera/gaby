import { spyReadRedis, spySaveRedis } from './spysRedis';

const getMockReadRedisByDatCacheJson = (fakeDataCacheJson) =>
  spyReadRedis.mockImplementation(() => fakeDataCacheJson);

const getMockSaveRedisByDatCacheJson = (fakeDataCacheJson) =>
  spySaveRedis.mockImplementation(() => fakeDataCacheJson);

export { getMockReadRedisByDatCacheJson, getMockSaveRedisByDatCacheJson };
