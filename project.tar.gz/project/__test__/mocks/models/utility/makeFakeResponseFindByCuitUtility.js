import {
  DPEC_CUIT,
  ECSAPEM_CUIT,
  GASNEA_CUIT,
  GASNOR_CUIT,
  LITORAL_GAS_CUIT,
  SCPL_CUIT,
} from '../../../utilitiesCuitTest';

const makeFakeUtilityByCuitAndName = (cuit, name, tapiUp = false) => ({
  cuit,
  name,
  baseUrl: 'http://localhost:8080',
  createdAt: '2022-05-19T15:43:40.000Z',
  tapiUp,
  companyCode: 'AR-S-0032',
  modalityId: '1',
});

const FAKE_UTILITIES = {
  [LITORAL_GAS_CUIT]: makeFakeUtilityByCuitAndName(LITORAL_GAS_CUIT, 'LITORAL'),
  [GASNEA_CUIT]: makeFakeUtilityByCuitAndName(GASNEA_CUIT, 'GASNEA'),
  [GASNOR_CUIT]: makeFakeUtilityByCuitAndName(GASNOR_CUIT, 'GASNOR'),
  [DPEC_CUIT]: makeFakeUtilityByCuitAndName(DPEC_CUIT, 'DPEC'),
  [ECSAPEM_CUIT]: makeFakeUtilityByCuitAndName(ECSAPEM_CUIT, 'ECSAPEM'),
  [SCPL_CUIT]: makeFakeUtilityByCuitAndName(SCPL_CUIT, 'SCPL'),
};

export const getFakeResponseFindByCuitUtilityByCuit = (cuit) => FAKE_UTILITIES[cuit];
