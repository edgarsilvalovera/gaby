import UtilityModel from '../../../../src/models/UtilityModel';

const spyInstanceUtilityModel = new UtilityModel();

const mockUtiliyModel = jest.mock('../../../../src/models/UtilityModel');

const spyFindByCuitUtility = mockUtiliyModel.spyOn(spyInstanceUtilityModel, 'findByCUIT');

export { spyFindByCuitUtility, spyInstanceUtilityModel };
