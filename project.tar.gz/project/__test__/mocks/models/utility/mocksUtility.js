import { spyFindByCuitUtility } from './spysUtility';

const getMockFindByCuitUtilityByFakeResponse = (fakeResponse) =>
  spyFindByCuitUtility.mockImplementation(() => fakeResponse);

export { getMockFindByCuitUtilityByFakeResponse };
