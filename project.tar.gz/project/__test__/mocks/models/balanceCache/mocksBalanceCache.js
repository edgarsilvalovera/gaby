import redisMock from 'redis-mock';
import BalancesCacheModel from '../../../../src/models/BalancesCacheModel';

const balancesCacheModel = new BalancesCacheModel();

const mockClientRedis = redisMock.createClient();
balancesCacheModel.client = mockClientRedis;
balancesCacheModel.client.connected = true;

const getMockBalancesCacheModel = () => balancesCacheModel;

export { getMockBalancesCacheModel };
