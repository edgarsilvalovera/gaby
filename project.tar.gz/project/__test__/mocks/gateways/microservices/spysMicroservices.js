import * as microservicesCallApi from '../../../../src/gateways/microservices/callAPI';
import * as microServicesBalancesIndex from '../../../../src/gateways/microservices/balances';

const spyCallApi = jest.spyOn(microservicesCallApi, 'default');

const spyGetBalancesService = jest.spyOn(microServicesBalancesIndex, 'default');

export { spyCallApi, spyGetBalancesService };
