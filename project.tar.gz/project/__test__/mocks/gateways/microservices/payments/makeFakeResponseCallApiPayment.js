import {
  DELSUR_CUIT,
  DPEC_CUIT,
  ECSAPEM_CUIT,
  EDENOR_CUIT,
  GASNEA_CUIT,
  GASNOR_CUIT,
  LITORAL_GAS_CUIT,
  METROGAS_CUIT,
  NATURGY_CUIT,
  PAMPEANA_CUIT,
  SCPL_CUIT,
} from '../../../../utilitiesCuitTest';

//response: paymentResponse, status: paymentStatus
const makeFakeResponseCallApiPayment = (cuit, data) => ({
  cuit,
  data,
  response: { payment_id: '1', transaction_id: '1', payment: {}, status: 'OK' },
});

const FAKE_RESPONSE_API_UTILITY = {
  [LITORAL_GAS_CUIT]: makeFakeResponseCallApiPayment(LITORAL_GAS_CUIT, []),
  [METROGAS_CUIT]: makeFakeResponseCallApiPayment(METROGAS_CUIT, []),
  [NATURGY_CUIT]: makeFakeResponseCallApiPayment(NATURGY_CUIT, []),
  [PAMPEANA_CUIT]: makeFakeResponseCallApiPayment(PAMPEANA_CUIT, []),
  [SCPL_CUIT]: makeFakeResponseCallApiPayment(SCPL_CUIT, []),
  [DELSUR_CUIT]: makeFakeResponseCallApiPayment(DELSUR_CUIT, []),
  [DPEC_CUIT]: makeFakeResponseCallApiPayment(DPEC_CUIT, []),
  [ECSAPEM_CUIT]: makeFakeResponseCallApiPayment(ECSAPEM_CUIT, []),
  [EDENOR_CUIT]: makeFakeResponseCallApiPayment(EDENOR_CUIT, []),
  [GASNEA_CUIT]: makeFakeResponseCallApiPayment(GASNEA_CUIT, []),
  [GASNOR_CUIT]: makeFakeResponseCallApiPayment(GASNOR_CUIT, []),
};

const getFakeResponseCallApiPaymentByCuit = (cuit) => FAKE_RESPONSE_API_UTILITY[cuit];

export { getFakeResponseCallApiPaymentByCuit };
