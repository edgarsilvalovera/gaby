import { spyCallApi } from '../spysMicroservices';
import { getFakeResponseCallApiPaymentByCuit } from './makeFakeResponseCallApiPayment';

const getMockCallApiPaymentByCuit = (cuit) => {
  let fakeResponseCallApiPayment = getFakeResponseCallApiPaymentByCuit(cuit);
  return spyCallApi.mockImplementation(() => Promise.resolve(fakeResponseCallApiPayment));
};

export { getMockCallApiPaymentByCuit };
