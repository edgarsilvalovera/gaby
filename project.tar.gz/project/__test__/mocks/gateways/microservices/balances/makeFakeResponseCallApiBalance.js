import { FAKE_RESPONSE_API_UTILITY } from '../../../../utilFakeBalances';

const getFakeResponseCallApiBalanceByCuit = (cuit) => FAKE_RESPONSE_API_UTILITY[cuit];

const getFakeBalanceResponseApiByCuit = (cuit) => ({
  request: {},
  response: getFakeResponseCallApiBalanceByCuit(cuit),
  status: 200,
});

export { getFakeResponseCallApiBalanceByCuit, getFakeBalanceResponseApiByCuit };
