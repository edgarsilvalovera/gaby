import { spyCallApi, spyGetBalancesService } from '../spysMicroservices';

const getMockCallApiBalanceByFakeResponse = (fakeResponse) =>
  spyCallApi.mockImplementation(() => Promise.resolve(fakeResponse));

const getMockGetBalancesServiceByFakeResponse = (fakeResponse) =>
  spyGetBalancesService.mockImplementation(() => fakeResponse);

export { getMockCallApiBalanceByFakeResponse, getMockGetBalancesServiceByFakeResponse };
