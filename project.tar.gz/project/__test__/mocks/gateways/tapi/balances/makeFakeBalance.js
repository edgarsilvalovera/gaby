import Fakerator from 'fakerator';
import moment from 'moment';
const faker = Fakerator('es-ES');

export const makeFakeBalance = (origin) => {
  const fakeBalance = {
    operationId: faker.random.string(),
    company: {
      companyCode: faker.random.string(4),
      comanyName: faker.random.string(),
    },
    customer: {
      customerId: faker.random.string(),
      customerName: faker.names.name(),
      customerAddress: faker.address.streetName(),
    },
    debts: [
      {
        debtId: faker.misc.uuid(),
        amount: faker.random.number(1, 99), //antes era amount1
        // deberia devolver un identificador del documento ?
        minAmount: faker.random.number(1, 9999),
        maxAmount: faker.random.number(1, 999999),
        expirationDate: moment().format('YYYYDDMM'), // primer vto
        amountType: 'Importe cerrado',
        expired: false,
        details: faker.random.string(),
        expirations: [
          //segundo vto con recargo (o tercer o los que sean)
          {
            expirationDate: moment().format('YYYYDDMM'),
            amount: faker.random.number(1, 9999),
          },
        ],
      },
    ],
  };

  return { ...fakeBalance, ...origin };
};
