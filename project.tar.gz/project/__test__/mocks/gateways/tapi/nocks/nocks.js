import nock from 'nock';
import TAPI from '../../../../../src/constants/tapi';
import Fakerator from 'fakerator';
import { makeFakeBalance } from '../balances/makeFakeBalance';
import { makeFakePayment } from '../payments/makeFakePayment';
const faker = Fakerator('es-ES');

const {
  services: { baseURL, balances, payments },
} = TAPI;

export const nockTapiBalance = (params, response) => {
  const mockResponse = response || makeFakeBalance();

  nock(baseURL, { allowUnmocked: true }).post(balances.endpoint).reply(200, mockResponse);

  return { mockResponse, params };
};

export const nockTapiBalanceError = (params = {}) => {
  const { data = {} } = params;

  nock(baseURL, { allowUnmocked: true })
    .post(balances.endpoint, data)
    .reply(500, { code: 'error' });
};

export const nockTapiPayment = (params, response) => {
  const { query = {} } = params || {};

  const mockResponse = response || makeFakePayment();

  nock(baseURL, { allowUnmocked: true })
    .post(payments.endpoint)
    .query(query)
    .reply(200, mockResponse);

  return { mockResponse };
};

export const nockTapiPaymentError = () => {
  nock(baseURL, { allowUnmocked: true }).post(payments.endpoint).reply(500, { code: 'error' });
};
