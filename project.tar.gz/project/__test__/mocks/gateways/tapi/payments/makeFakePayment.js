import Fakerator from 'fakerator';
const faker = Fakerator('es-ES');

export const makeFakePayment = (origin) => {
  const fakeResponse = {
    operation: {
      mainTx: faker.misc.uuid(),
      tx: faker.misc.uuid(),
      transactionId: faker.random.number(1, 100),
      externalRef: faker.misc.uuid(),
      externalPaymentId: faker.misc.uuid(),
      operationId: faker.misc.uuid(),
      operationStatus: 'NEW',
      debtId: `${faker.misc.uuid()}-0`,
      amount: 4716.87,
      paymentMethod: 'CRE',
      createdAt: null,
      updateAt: '2022-07-14T13:21:41.000Z',
    },
    status: '200',
  };

  return { ...fakeResponse, ...origin };
};
