import Fakerator from 'fakerator';
const faker = Fakerator('es-ES');

export const makeFakeBalanceRequest = (origin = {}) => {
  const {
    utility = faker.random.string(4),
    data: {
      companyCode = faker.random.string(8),
      modalityId = faker.misc.uuid(),
      queryData = { invoiceId: faker.random.string(10) },
    } = {},
    headers = {},
  } = origin;

  return {
    data: { companyCode, modalityId, queryData },
    headers,
    utility,
  };
};

export const makeFakePaymentRequest = (origin = {}) => {
  const {
    utility = faker.random.string(4),
    data: {
      amount = faker.random.number(1, 9999),
      debtId = faker.misc.uuid() + '-0',
      companyCode = faker.random.string(10),
      paymentMethod = faker.random.string(5),
      operationId = faker.misc.uuid(),
      expirationDate = faker.date.recent().toISOString(),
      type = faker.random.string(5),
      companyName = faker.random.string(10),
    } = {},
    headers = {},
  } = origin;

  return {
    data: {
      amount,
      debtId,
      companyCode,
      paymentMethod,
      operationId,
      expirationDate,
      type,
      companyName,
    },
    utility,
    headers,
  };
};
