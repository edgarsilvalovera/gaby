import AWS from 'aws-sdk';
import AWSMock from 'aws-sdk-mock';
import sendMessageQueues from '../../../../../src/gateways/aws/sendMessageQueues';
import { keysToPascal } from '../../../../../src/helpers/keyParsers';

AWSMock.setSDKInstance(AWS);
AWSMock.mock('SQS', 'sendMessage', () => Promise.resolve('success'));
const mockSqsAws = new AWS.SQS();

const getMockSendSqsMessageSqs = () => {
  const mockSendMessageQueuesInstance = sendMessageQueues({ SqsAws: mockSqsAws, keysToPascal });
  const mockSendSqsMessage = {
    sendMessageQueues: mockSendMessageQueuesInstance,
  };
  return mockSendSqsMessage;
};

export { getMockSendSqsMessageSqs };
