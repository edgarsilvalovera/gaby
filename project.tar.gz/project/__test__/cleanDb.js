import UtilityModel from '../src/models/UtilityModel';

const cleanDb = async () => {
  const models = [new UtilityModel()];
  await cleanTablesDb(models);
};

const cleanTablesDb = async (models) => {
  for (const model of models) {
    await model.deleteAll().catch((error) => {
      console.error(error);
    });
  }
};

export { cleanDb };
