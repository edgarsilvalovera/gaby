import Fakerator from 'fakerator';
import {
  DELSUR_CUIT,
  DPEC_CUIT,
  ECSAPEM_CUIT,
  EDENOR_CUIT,
  GASNEA_CUIT,
  GASNOR_CUIT,
  getNameUtilityByCuit,
  LITORAL_GAS_CUIT,
  METROGAS_CUIT,
  NATURGY_CUIT,
  PAMPEANA_CUIT,
  SCPL_CUIT,
} from './utilitiesCuitTest';
const faker = Fakerator('es-ES');

//by default fake balance takes litoral gas response
//TODO : to be more acurate we should mock each specific response
const fakeBalances = [
  {
    amount: 10,
    isPayable: true,
    concept: '40',
    message: 'message test',
    dueDate: new Date(),
  },
  {
    amount: 30,
    isPayable: true,
    concept: '40',
    message: 'message test 2',
    dueDate: new Date(),
  },
];

const fakeBalancesByCuit = {
  [LITORAL_GAS_CUIT]: fakeBalances,
  [METROGAS_CUIT]: fakeBalances,
  [NATURGY_CUIT]: fakeBalances,
  [PAMPEANA_CUIT]: fakeBalances,
  [SCPL_CUIT]: fakeBalances,
  [DELSUR_CUIT]: fakeBalances,
  [DPEC_CUIT]: fakeBalances,
  [ECSAPEM_CUIT]: fakeBalances,
  [EDENOR_CUIT]: { saldos: fakeBalances },
  [GASNEA_CUIT]: fakeBalances,
  [GASNOR_CUIT]: fakeBalances,
};

const getBalancesByCuit = (cuit) => fakeBalancesByCuit[cuit];

const makeFakeResponseApi = (cuitUtility, data) => ({
  message: 'OK',
  utility: getNameUtilityByCuit(cuitUtility),
  mainTx: faker.misc.uuid(),
  tx: '',
  paymentDocument: faker.random.masked('9999999999'),
  balances: getBalancesByCuit(cuitUtility),
  data,
});

const FAKE_RESPONSE_API_UTILITY = {
  [LITORAL_GAS_CUIT]: makeFakeResponseApi(LITORAL_GAS_CUIT, []),
  [METROGAS_CUIT]: makeFakeResponseApi(METROGAS_CUIT, []),
  [NATURGY_CUIT]: makeFakeResponseApi(NATURGY_CUIT, []),
  [PAMPEANA_CUIT]: makeFakeResponseApi(PAMPEANA_CUIT, []),
  [SCPL_CUIT]: makeFakeResponseApi(SCPL_CUIT, []),
  [DELSUR_CUIT]: makeFakeResponseApi(DELSUR_CUIT, []),
  [DPEC_CUIT]: makeFakeResponseApi(DPEC_CUIT, []),
  [ECSAPEM_CUIT]: makeFakeResponseApi(ECSAPEM_CUIT, []),
  [EDENOR_CUIT]: makeFakeResponseApi(EDENOR_CUIT, []),
  [GASNEA_CUIT]: makeFakeResponseApi(GASNEA_CUIT, []),
  [GASNOR_CUIT]: makeFakeResponseApi(GASNOR_CUIT, []),
};

export { FAKE_RESPONSE_API_UTILITY };
