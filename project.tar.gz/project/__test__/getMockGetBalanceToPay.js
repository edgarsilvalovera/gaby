import adapters from '../src/adapters/microservices';
import { logError } from '../src/logger/';
import { getMockCacheDataRedis } from './getMockCacheDataRedis';
import getBalanceToPayUsecaseAction from '../src/usecases/payments/getBalanceToPayUsecaseAction';

const parameters = { adapters, logError };

const getMockGetBalanceToPay = async (fakeRequestParamsPayment) => {
  const {
    body: { searchId: searchIdExecuter, balanceId },
  } = fakeRequestParamsPayment;

  const cacheData = await getMockCacheDataRedis();

  const executer = getBalanceToPayUsecaseAction(parameters);
  const balanceToPay = await executer(searchIdExecuter, balanceId, cacheData);

  return balanceToPay;
};

export { getMockGetBalanceToPay };
