import Fakerator from 'fakerator';
import { BalancesRequestValidator } from '../src/entities';
import { getFakeUtilityByCuit } from './makeFakeUtility';
import { LITORAL_GAS_CUIT } from './utilitiesCuitTest';

const faker = Fakerator('es-ES');

let fakeUtiliy = getFakeUtilityByCuit(LITORAL_GAS_CUIT);

export const fakeRequestParams = {
  urlParams: {
    document: '15',
    cuit: LITORAL_GAS_CUIT,
  },
  queryParams: {
    qrType: 'iep',
    pspId: faker.random.string(4),
  },
  headers: {
    'x-main-tx': faker.misc.uuid(),
    accountId: '456',
  },
};

export const fakeRequestParamsWithError = {
  urlParams: {
    document: '15',
  },
  queryParams: {
    qrType: 'ABC',
  },
  headers: {
    'x-main-tx': faker.misc.uuid(),
    accountId: '456',
  },
};

let newRequestParams = {
  ...fakeRequestParams,
  queryParams: {
    ...fakeRequestParams.queryParams,
    cuit: fakeUtiliy.cuit,
  },
  baseURL: fakeUtiliy.baseUrl,
  utility: fakeUtiliy.name,
};

export const fakeValidatedRequestParams = new BalancesRequestValidator(newRequestParams);
