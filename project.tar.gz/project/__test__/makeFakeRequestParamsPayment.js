import Fakerator from 'fakerator';
import * as uuid from 'uuid';
import EMU from '../src/constants/emu';
import { FAKE_SEARCH_ID } from './utilFakeId';

const faker = Fakerator('es-ES');

const mainTx = faker.misc.uuid();

const {
  paymentMethods: { tap },
} = EMU;

const bodyJson = {
  searchId: FAKE_SEARCH_ID,
  balanceId: uuid.v4(),
  mainTx: mainTx,
  totalAmount: 10,
  paymentMethod: tap,
  pspId: 1,
};

const fakeRequestParamsPayment = {
  headers: {
    'x-main-tx': mainTx,
    accountId: '456',
  },
  urlParams: {},
  queryParams: {},
  body: {
    body: JSON.stringify(bodyJson),
  },
  //globalStartTime: startTime,
};

//add make response passing searchId

const makeFakePaymentRequest = (body = {}) => {
  return {
    headers: {
      'x-main-tx': mainTx,
      accountId: '456',
    },
    queryParams: {},
    body: {
      body: JSON.stringify({ ...bodyJson, ...body }),
    },
  };
};

export { fakeRequestParamsPayment, makeFakePaymentRequest };
