import Fakerator from 'fakerator';
import {
  DPEC_CUIT,
  ECSAPEM_CUIT,
  GASNEA_CUIT,
  GASNOR_CUIT,
  LITORAL_GAS_CUIT,
  SCPL_CUIT,
  getNameUtilityByCuit,
} from './utilitiesCuitTest';

const faker = Fakerator('es-ES');

const makeFakeUtilityByCuitAndName = (cuit, name) => ({
  cuit,
  name,
  baseUrl: 'http://localhost:8080',
  createdAt: '2022-05-19T15:43:40.000Z',
  companyCode: faker.company.suffix(),
  modalityId: faker.random.string(40),
});

const FAKE_UTILITIES = {
  [LITORAL_GAS_CUIT]: makeFakeUtilityByCuitAndName(
    LITORAL_GAS_CUIT,
    getNameUtilityByCuit(LITORAL_GAS_CUIT),
  ),
  [GASNEA_CUIT]: makeFakeUtilityByCuitAndName(GASNEA_CUIT, getNameUtilityByCuit(GASNEA_CUIT)),
  [GASNOR_CUIT]: makeFakeUtilityByCuitAndName(GASNOR_CUIT, getNameUtilityByCuit(GASNOR_CUIT)),
  [DPEC_CUIT]: makeFakeUtilityByCuitAndName(DPEC_CUIT, getNameUtilityByCuit(DPEC_CUIT)),
  [ECSAPEM_CUIT]: makeFakeUtilityByCuitAndName(ECSAPEM_CUIT, getNameUtilityByCuit(ECSAPEM_CUIT)),
  [SCPL_CUIT]: makeFakeUtilityByCuitAndName(SCPL_CUIT, getNameUtilityByCuit(SCPL_CUIT)),
};

export const getFakeUtilityByCuit = (cuit) => FAKE_UTILITIES[cuit];
