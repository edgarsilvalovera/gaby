import getBalancesUsecaseAction from '../src/usecases/cache/getBalancesUsecaseAction';
import { getMockBalancesCacheModel } from './mocks/models/balanceCache/mocksBalanceCache';
import { fakeResponseBalance } from './mocks/models/redis/makeFakeResponseReadRedis';

const mockBalancesCacheModel = getMockBalancesCacheModel();
const parametersBalancesUsecaseAction = {
  balancesCacheModel: mockBalancesCacheModel,
};

const {
  parsedResponse: {
    balancesInfo: { searchId },
  },
} = fakeResponseBalance;

const getMockCacheDataRedis = async () => {
  const getCachedBalances = getBalancesUsecaseAction(parametersBalancesUsecaseAction);
  return getCachedBalances(searchId);
};

export { getMockCacheDataRedis };
