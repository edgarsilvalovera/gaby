import { config } from 'config';
import getBalancesUsecaseAction from '../../src/usecases/cache/getBalancesUsecaseAction';
import getBalanceToPayUsecaseAction from '../../src/usecases/payments/getBalanceToPayUsecaseAction';
import { getMockBalancesCacheModel } from '../mocks/models/balanceCache/mocksBalanceCache';
import { getFakeResponseReadRedisByCuit } from '../mocks/models/redis/makeFakeResponseReadRedis';
import { getMockReadRedisByDatCacheJson } from '../mocks/models/redis/mockRedis';
import { LITORAL_GAS_CUIT } from '../utilitiesCuitTest';
import adapters from '../../src/adapters/microservices';
import { logError, logInfo } from '../../src/logger/';
import { getMockCallApiPaymentByCuit } from '../mocks/gateways/microservices/payments/mocksMicroservicesPayment';
import { getPaymentEntityUsecaseInstance } from '../../src/usecases/utilities';
import notifyPaymentsService from '../../src/gateways/microservices/payments/notifyPaymentsService';
import { parseRequestPayments, parseResponsePayments } from '../../src/adapters/parsePayments';
import callAPI from '../../src/gateways/microservices/callAPI';
import notifyPaymentsUsecaseAction from '../../src/usecases/payments/notifyPaymentsUsecaseAction';
import instanceGetDefault from '../../src/usecases/sqs/sendSqsMessage';
import { getMockSendSqsMessageSqs } from '../mocks/gateways/aws/sqs/mocksAwsSqs';

//make parameter getBalancesUsecaseInstance
const fakeDataCache = getFakeResponseReadRedisByCuit(LITORAL_GAS_CUIT);
const fakeDataCacheJson = JSON.parse(fakeDataCache);

getMockReadRedisByDatCacheJson(fakeDataCacheJson);

const parametersBalancesUsecaseAction = {
  balancesCacheModel: getMockBalancesCacheModel(),
};

const getBalancesUsecaseInstance = getBalancesUsecaseAction(parametersBalancesUsecaseAction);

//make parameter getBalanceToPayUsecaseInstance
const parametersGetBalance = { adapters, logError };
const getBalanceToPayUsecaseInstance = getBalanceToPayUsecaseAction(parametersGetBalance);

//make parameter notifyPaymentsUsecaseInstance
const mockCallApiPayment = getMockCallApiPaymentByCuit(LITORAL_GAS_CUIT);

const notifyPaymentsServiceInstance = notifyPaymentsService({
  callAPI,
});

const parametersNotifyPayment = {
  getPaymentEntity: getPaymentEntityUsecaseInstance,
  parseRequestPayments,
  notifyPayment: notifyPaymentsServiceInstance,
};
const notifyPaymentsUsecaseInstance = notifyPaymentsUsecaseAction(parametersNotifyPayment);

//make parameter sendSqsMessage
const { fiatQueueURL } = config;

const mockSendSqsMessage = getMockSendSqsMessageSqs();

const dependencies = {
  dependencies: {
    logInfo,
    Aws: mockSendSqsMessage,
    queueUrl: fiatQueueURL,
  },
};

const sendSqsMessage = instanceGetDefault(dependencies);

const parametersNotifyPaymentsControllerAction = {
  getCachedBalances: getBalancesUsecaseInstance,
  getBalanceToPay: getBalanceToPayUsecaseInstance,
  notifyPayments: notifyPaymentsUsecaseInstance,
  parseResponsePayments,
  sendSqsMessage,
  logError,
};

export { parametersNotifyPaymentsControllerAction };
