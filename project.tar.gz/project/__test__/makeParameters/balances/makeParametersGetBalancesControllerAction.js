import { BalancesRequestValidator } from '../../../src/entities';
import * as microServicesBalancesIndex from '../../../src/gateways/microservices/balances/index';
import getBalancesUsecaseAction from '../../../src/usecases/balances/getBalancesUsecaseAction';
import saveBalancesUsecaseAction from '../../../src/usecases/cache/saveBalancesUsecaseAction';
import getUtilityUsecaseAction from '../../../src/usecases/utilities/getUtilityUsecaseAction';
import { getFakeBalanceResponseApiByCuit } from '../../mocks/gateways/microservices/balances/makeFakeResponseCallApiBalance';
import { getMockGetBalancesServiceByFakeResponse } from '../../mocks/gateways/microservices/balances/mocksMicroservicesBalance';
import { getMockBalancesCacheModel } from '../../mocks/models/balanceCache/mocksBalanceCache';
import { getFakeResponseReadRedisByCuit } from '../../mocks/models/redis/makeFakeResponseReadRedis';
import { getMockSaveRedisByDatCacheJson } from '../../mocks/models/redis/mockRedis';
import { getMockFindByCuitUtilityByFakeResponse } from '../../mocks/models/utility/mocksUtility';
import { LITORAL_GAS_CUIT } from '../../utilitiesCuitTest';
import { logError } from '../../../src/logger';
import parseBalances from '../../../src/adapters/parseBalances';
import { spyInstanceUtilityModel } from '../../mocks/models/utility/spysUtility';
import { getFakeResponseFindByCuitUtilityByCuit } from '../../mocks/models/utility/makeFakeResponseFindByCuitUtility';

//make parameter getUtility
const fakeUtility = getFakeResponseFindByCuitUtilityByCuit(LITORAL_GAS_CUIT);

getMockFindByCuitUtilityByFakeResponse(fakeUtility);

const utilityModel = spyInstanceUtilityModel;
let parameters = {
  utilityModel: utilityModel,
  logError,
};
const getUtility = getUtilityUsecaseAction(parameters);

//make parameter getBalance
const fakeResponseApi = getFakeBalanceResponseApiByCuit(LITORAL_GAS_CUIT);

getMockGetBalancesServiceByFakeResponse(fakeResponseApi);

parameters = {
  Validator: BalancesRequestValidator,
  getBalances: microServicesBalancesIndex.default,
};
const getBalances = getBalancesUsecaseAction(parameters);

//make parameter saveBalancesUsecaseAction
const fakeDataCache = getFakeResponseReadRedisByCuit(LITORAL_GAS_CUIT);
const fakeDataCacheJson = JSON.parse(fakeDataCache);
fakeDataCacheJson.request.params.cuit = LITORAL_GAS_CUIT;

getMockSaveRedisByDatCacheJson(fakeDataCacheJson);

const balancesCacheModel = getMockBalancesCacheModel();
parameters = {
  balancesCacheModel: balancesCacheModel,
};
const saveBalances = saveBalancesUsecaseAction(parameters);

//make injection dependencies
const parametersGetBalancesControllerAction = {
  getUtility,
  getBalances,
  parseBalances,
  saveBalances,
};

export { parametersGetBalancesControllerAction };
