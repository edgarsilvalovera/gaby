export const LITORAL_GAS_CUIT = '30657866330';
export const METROGAS_CUIT = '30657863676';
export const NATURGY_CUIT = '30657864117';
export const PAMPEANA_CUIT = '30657864281';
export const SCPL_CUIT = '30545726722';
export const DELSUR_CUIT = '30657864427';
export const DPEC_CUIT = '30608090181';
export const ECSAPEM_CUIT = '30712262903';
export const EDENOR_CUIT = '30655116202';
export const GASNEA_CUIT = '30691210878';
export const GASNOR_CUIT = '30657865725';

export const NAME_UTILITIES = {
  [LITORAL_GAS_CUIT]: 'Litoral Gas',
  [METROGAS_CUIT]: 'Metro Gas',
  [NATURGY_CUIT]: 'Naturgy',
  [PAMPEANA_CUIT]: 'Pampeana',
  [SCPL_CUIT]: 'SCPL',
  [DELSUR_CUIT]: 'Del Sur',
  [DPEC_CUIT]: 'DPEC',
  [ECSAPEM_CUIT]: 'ECSAPEM',
  [EDENOR_CUIT]: 'EDENOR',
  [GASNEA_CUIT]: 'Gasnea',
  [GASNOR_CUIT]: 'Gasnor',
};

export const getNameUtilityByCuit = (cuit) => NAME_UTILITIES[cuit];
