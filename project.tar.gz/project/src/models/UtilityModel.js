import PostgresModel from './PostgresModel';

class UtilityModel extends PostgresModel {
  constructor() {
    super('utilities');
  }

  async findByCUIT(cuit) {
    return this.findFirst({ cuit });
  }
}

export default UtilityModel;
