import RedisModel from './RedisModel';

class BalancesCacheModel extends RedisModel {
  constructor() {
    super();
  }

  async save(id, data) {
    return this.set(`balances:${id}`, data);
  }

  async read(id) {
    return this.get(`balances:${id}`);
  }
}

export default BalancesCacheModel;
