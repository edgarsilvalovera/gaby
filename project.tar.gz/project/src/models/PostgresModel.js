import knex from 'knex';
import knexStringcase from 'knex-stringcase';
import { logInfo, logError } from '../logger/';
import * as exceptions from '../exceptions/';
import config from '../../knexfile.js';

class PostgresModel {
  constructor(tableName) {
    const dbOptions = knexStringcase(config[process.env.NODE_ENV || 'develop']);

    this.tableName = tableName;
    this.dbInstance = knex(dbOptions);
    this.joinTypes = {
      inner: 'innerJoin',
      left: 'leftJoin',
      right: 'rightJoin',
      leftOuter: 'leftOuterJoin',
      rightOuter: 'rightOuterJoin',
      fullOuter: 'fullOuterJoin',
    };
  }

  builder() {
    return this.dbInstance(this.tableName);
  }

  async create(params) {
    const query = this.builder().insert(params).returning('*');
    this.logQuery(query);

    const [result] = await query.catch((error) => {
      logError({
        message: 'sql-insert failed in postgres',
        metadata: error,
        filename: __filename,
      });

      throw new exceptions.PostgresFailedInsert();
    });

    return result;
  }

  /*
    params with single AND equality-conditions = { col1: val1, ..., colN: valN }
    - SQL = "... where col1 = val1 and ... and colN = valN ..."

    params with multiple AND/OR conditions = [
      [{ column: col1, value: val1, operator: '>'}, { column: col2, value: val2, operator: '!='}],
      [{ column: col3, value: val3, operator: '<'}],
    ]
    - SQL = "... where 1 = 0 or (1 = 1 and col1 > val1 and col2 != val2) or (1 = 1 and col3 < val3) ..."
    - "1 = 0" & "1 = 1" are just for convenience during the sql-statement building (most of DB engines discard them)
    - operator default is '='
  */
  async find(params = null, join = null, orderBy = null, first = false) {
    const tableInstance = this.builder();

    if (params) {
      if (Array.isArray(params)) {
        // begin OR statements
        tableInstance.whereRaw('?? = ??', [1, 0]);

        // loop main elements
        params.forEach((element) => {
          // build OR statements
          tableInstance.orWhere((builder) => {
            // begin AND sub-statements
            builder.whereRaw('?? = ??', [1, 1]);

            // loop sub-elements
            element.forEach((subElement) => {
              const { column, operator = '=', value } = subElement;
              // build AND sub-statements
              builder.andWhere(column, operator, value);
            });

            return builder;
          });
        });
      } else if (typeof params === 'object') {
        tableInstance.where({ ...params });
      }
    }

    if (join) {
      const addJoin = function (element) {
        const { table, column, operator = '=', foreignKey = null, type = 'inner' } = element;
        const joinType = this.joinTypes[type];

        tableInstance[joinType](
          table,
          `${this.tableName}.${column}`,
          operator,
          `${table}.${foreignKey || column}`,
        );
      };

      if (Array.isArray(join)) {
        join.forEach((element) => {
          addJoin(element);
        });
      } else if (typeof join === 'object') {
        addJoin(join);
      }
    }

    if (orderBy) {
      if (Array.isArray(orderBy)) {
        tableInstance.orderBy(orderBy);
      } else if (typeof orderBy === 'object') {
        const { column, order = 'asc' } = orderBy;
        tableInstance.orderBy(column, order);
      }
    }

    if (first) {
      tableInstance.first();
    }

    this.logQuery(tableInstance);

    return tableInstance.catch((error) => {
      logError({
        message: 'sql-select failed in postgres',
        metadata: error,
        filename: __filename,
      });

      throw new exceptions.PostgresFailedSelect();
    });
  }

  async findFirst(params = null, join = null, orderBy = null) {
    return this.find(params, join, orderBy, true);
  }

  async findOrCreate(params) {
    const result = await this.findFirst(params);
    return result ? result : this.create(params);
  }

  async update(setParams, whereParams) {
    if (!whereParams) {
      throw new exceptions.PostgresUnsafeUpdate();
    }

    const query = this.builder().where(whereParams).update(setParams).returning('*');
    this.logQuery(query);

    const [data] = await query.catch((error) => {
      logError({
        message: 'sql-update failed in postgres',
        metadata: error,
        filename: __filename,
      });

      throw new exceptions.PostgresFailedUpdate();
    });

    return data;
  }

  async updateIn(setParams, whereField, whereArray) {
    if (!whereField || !whereArray) {
      throw new exceptions.PostgresUnsafeUpdate();
    }

    const query = this.builder().whereIn(whereField, whereArray).update(setParams).returning('*');
    this.logQuery(query);

    return query.catch((error) => {
      logError({
        message: 'sql-update-in failed in postgres',
        metadata: error,
        filename: __filename,
      });

      throw new exceptions.PostgresFailedUpdateIn();
    });
  }

  async deleteAll() {
    const query = this.builder().del();
    this.logQuery(query);

    await query.catch((error) => {
      logError({
        message: 'sql-delete-all failed in postgres',
        metadata: error,
        filename: __filename,
      });

      throw new exceptions.PostgresFailedDeleteAll();
    });
  }

  async deleteWhere(params) {
    if (!params) {
      throw new exceptions.PostgresUnsafeDelete();
    }

    const query = this.builder().where(params).del();
    this.logQuery(query);

    await query.catch((error) => {
      logError({
        message: 'sql-delete-where failed in postgres',
        metadata: error,
        filename: __filename,
      });

      throw new exceptions.PostgresFailedDeleteWhere();
    });
  }

  async count() {
    const query = this.builder().count();
    this.logQuery(query);

    const [{ count }] = await query.catch((error) => {
      logError({
        message: 'sql-select-count failed in postgres',
        metadata: error,
        filename: __filename,
      });

      throw new exceptions.PostgresFailedSelectCount();
    });

    return +count;
  }

  async execute(sql) {
    const query = this.dbInstance.raw(sql);
    this.logQuery(query);

    return query.catch((error) => {
      logError({
        message: 'sql-raw failed in postgres',
        metadata: error,
        filename: __filename,
      });

      throw new exceptions.PostgresFailedRawStatement();
    });
  }

  logQuery(query) {
    const { sql, bindings } = query.toSQL().toNative();

    logInfo({
      message: 'sql statement for postgres',
      metadata: { sql, bindings },
      filename: __filename,
    });
  }
}

export default PostgresModel;
