import { config } from 'config';
import redis from 'redis';
import { promisify } from 'util';
import EMU from '../constants/emu';
import { logInfo, logError } from '../logger/';
import { RedisFailedSetter, RedisFailedGetter, RedisUnexpectedError } from '../exceptions/';

const {
  redis: { host, port },
} = config;

const {
  redis: { expiration },
} = EMU;

class RedisModel {
  constructor() {
    this.client = { connected: false };
    this.setAsync = null;
    this.getAsync = null;
  }

  connect() {
    this.client = redis.createClient({ host, port });
    this.attachErrorEvent();
    this.promisifyActions();
  }

  attachErrorEvent() {
    this.client.on('error', (error) => {
      logError({
        message: 'an error has ocurred on redis',
        metadata: error,
        filename: __filename,
      });

      throw new RedisUnexpectedError();
    });
  }

  promisifyActions() {
    this.setAsync = promisify(this.client.setex).bind(this.client);
    this.getAsync = promisify(this.client.get).bind(this.client);
  }

  async set(key, value) {
    !this.client.connected && this.connect();

    const response = await this.setAsync(key, expiration, JSON.stringify(value)).catch((error) => {
      logError({
        message: 'cannot set a key on redis',
        metadata: error,
        filename: __filename,
      });

      throw new RedisFailedSetter();
    });

    logInfo({
      message: 'a new key was cached on redis',
      metadata: { key, value },
      filename: __filename,
    });

    return response;
  }

  async get(key) {
    !this.client.connected && this.connect();

    const jsonString = await this.getAsync(key).catch((error) => {
      logError({
        message: 'cannot get a key from redis',
        metadata: error,
        filename: __filename,
      });

      throw new RedisFailedGetter();
    });

    const value = jsonString ? JSON.parse(jsonString) : null;

    logInfo({
      message: 'a key was retrieved from redis',
      metadata: { key, value },
      filename: __filename,
    });

    return value;
  }
}

export default RedisModel;
