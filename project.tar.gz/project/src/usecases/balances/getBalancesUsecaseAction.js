function getBalancesUsecaseAction({ Validator, getBalances }) {
  async function executer({ requestParams, utility }) {
    // build the request
    const newRequestParams = {
      ...requestParams,
      queryParams: {
        ...requestParams.queryParams,
        cuit: utility.cuit,
      },
      baseURL: utility.baseUrl,
      utility: utility.name,
    };

    const validatedRequestParams = new Validator(newRequestParams);

    return getBalances(validatedRequestParams);
  }

  return executer;
}

export default getBalancesUsecaseAction;
