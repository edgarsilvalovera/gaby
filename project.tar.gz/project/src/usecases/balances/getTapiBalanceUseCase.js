import { tapiBalanceRequestEntity } from '../../entities/tapi';

const getTapiBalanceUseCase =
  ({ getBalances }) =>
  async ({ utility, requestParams }) => {
    const { headers, urlParams, queryParams } = requestParams;

    const { companyCode, name, modalityId } = utility;

    const { document } = urlParams;
    const { pspId } = queryParams;

    const request = {
      headers,
      data: {
        companyCode,
        modalityId,
        queryData: { invoiceId: document, pspId },
      },
      utility: name,
    };

    const tapiRequest = tapiBalanceRequestEntity(request);

    return getBalances(tapiRequest);
  };

export default getTapiBalanceUseCase;
