import getBalancesUsecaseAction from './getBalancesUsecaseAction';
import getTapiBalanceUseCase from './getTapiBalanceUseCase';
import { BalancesRequestValidator } from '../../entities/';
import getBalancesServiceInstance from '../../gateways/microservices/balances/';
import { checkBillInstance } from '../../gateways/tapi';

const getBalancesUsecaseInstance = getBalancesUsecaseAction({
  Validator: BalancesRequestValidator,
  getBalances: getBalancesServiceInstance,
});

const getTapiBalanceInstance = getTapiBalanceUseCase({
  Validator: BalancesRequestValidator,
  getBalances: checkBillInstance,
});

export { getBalancesUsecaseInstance, getTapiBalanceInstance };
