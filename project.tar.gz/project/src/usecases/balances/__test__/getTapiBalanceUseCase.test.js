import { BalancesRequestValidator } from '../../../entities';
import { LITORAL_GAS_CUIT } from '../../../../__test__/utilitiesCuitTest';
import { fakeRequestParams } from '../../../../__test__/makeFakeRequestParamsBalance';
import { getFakeUtilityByCuit } from '../../../../__test__/makeFakeUtility';
import * as microServicesBalancesIndex from '../../../gateways/microservices/balances';
import { getMockGetBalancesServiceByFakeResponse } from '../../../../__test__/mocks/gateways/microservices/balances/mocksMicroservicesBalance';
import { getFakeResponseCallApiBalanceByCuit } from '../../../../__test__/mocks/gateways/microservices/balances/makeFakeResponseCallApiBalance';
import getTapiBalanceUseCase from '../getTapiBalanceUseCase';

const fakeResponseApi = getFakeResponseCallApiBalanceByCuit(LITORAL_GAS_CUIT);

getMockGetBalancesServiceByFakeResponse(fakeResponseApi);

const parameters = {
  Validator: BalancesRequestValidator,
  getBalances: microServicesBalancesIndex.default,
};

describe('Get Tapi Balance Use Case', () => {
  beforeEach(() => {
    getMockGetBalancesServiceByFakeResponse(fakeResponseApi);
  });

  afterEach(() => {
    jest.clearAllMocks();
    jest.restoreAllMocks();
  });

  it('Method getTapiBalanceUseCase() should return a function', async () => {
    let executer = getTapiBalanceUseCase(parameters);

    expect(typeof executer).toBe('function');
  });

  it('Method executer() should return a Response Balance', async () => {
    let executer = getTapiBalanceUseCase(parameters);

    const fakeUtility = getFakeUtilityByCuit(LITORAL_GAS_CUIT);

    let balance = await executer({ requestParams: fakeRequestParams, utility: fakeUtility });

    expect(balance.message).toBe(fakeResponseApi.message);
  });
});
