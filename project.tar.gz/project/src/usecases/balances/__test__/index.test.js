import * as balancesIndex from '..';
import { getTapiBalanceInstance } from '..';

import { nockTapiBalance } from '../../../../__test__/mocks/gateways/tapi/nocks/nocks';
import { fakeRequestParams } from '../../../../__test__/makeFakeRequestParamsBalance';

describe('Get Balance Usecase Instance', () => {
  it('Method getBalancesUsecaseInstance() should return a function', () => {
    const fakeExecuter = async () => {};

    const fakeGetBalancesUsecaseAction = jest
      .spyOn(balancesIndex, 'getBalancesUsecaseInstance')
      .mockImplementation(() => fakeExecuter);

    const getBalancesUsecaseInstance = balancesIndex.getBalancesUsecaseInstance();

    expect(fakeGetBalancesUsecaseAction).toHaveBeenCalled();
    expect(typeof getBalancesUsecaseInstance).toBe('function');
  });

  it('should return tapi balance response', async () => {
    const { mockResponse } = nockTapiBalance();

    const useCaseResponse = await getTapiBalanceInstance({
      utility: { name: 'TAPI', modalityId: '1', companyCode: 'AR-S-0032' },
      requestParams: fakeRequestParams,
    });
    expect(useCaseResponse).toHaveProperty('request');
    expect(useCaseResponse).toHaveProperty('response');
    expect(useCaseResponse.response).toEqual(expect.objectContaining(mockResponse));
  });
});
