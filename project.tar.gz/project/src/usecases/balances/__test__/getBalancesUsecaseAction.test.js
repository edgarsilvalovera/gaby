import getBalancesUsecaseAction from '../getBalancesUsecaseAction';
import { BalancesRequestValidator } from '../../../entities';
import { LITORAL_GAS_CUIT } from '../../../../__test__/utilitiesCuitTest';
import {
  fakeRequestParams,
  fakeRequestParamsWithError,
} from '../../../../__test__/makeFakeRequestParamsBalance';
import { getFakeUtilityByCuit } from '../../../../__test__/makeFakeUtility';
import { expectCodeThrowsAsync } from '../../../../__test__/expectThrowsAsync';
import * as microServicesBalancesIndex from '../../../gateways/microservices/balances';
import { getMockGetBalancesServiceByFakeResponse } from '../../../../__test__/mocks/gateways/microservices/balances/mocksMicroservicesBalance';
import { getFakeResponseCallApiBalanceByCuit } from '../../../../__test__/mocks/gateways/microservices/balances/makeFakeResponseCallApiBalance';

const fakeResponseApi = getFakeResponseCallApiBalanceByCuit(LITORAL_GAS_CUIT);

getMockGetBalancesServiceByFakeResponse(fakeResponseApi);

const parameters = {
  Validator: BalancesRequestValidator,
  getBalances: microServicesBalancesIndex.default,
};

const fakeUtility = getFakeUtilityByCuit(LITORAL_GAS_CUIT);

describe('Get Balance Use Case Action', () => {
  beforeEach(() => {
    getMockGetBalancesServiceByFakeResponse(fakeResponseApi);
  });

  afterEach(() => {
    jest.clearAllMocks();
    jest.restoreAllMocks();
  });

  it('Method getBalancesUsecaseAction() should return a function', () => {
    let executer = getBalancesUsecaseAction(parameters);

    expect(typeof executer).toBe('function');
  });

  it('Method executer() should return a Exception', async () => {
    let executer = getBalancesUsecaseAction(parameters);

    let method = () =>
      executer({ requestParams: fakeRequestParamsWithError, utility: fakeUtility });
    let errorMessage = 'UT04000';
    await expectCodeThrowsAsync(method, errorMessage);
  });

  it('Method executer() should return a Response Api Litoral', async () => {
    let executer = getBalancesUsecaseAction(parameters);

    let balance = await executer({ requestParams: fakeRequestParams, utility: fakeUtility });

    expect(balance.message).toBe(fakeResponseApi.message);
  });
});
