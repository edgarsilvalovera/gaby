import utilities from '../../adapters/microservices/';
import { PaymentEntityNotFound } from '../../exceptions/';

function getPaymentEntityUsecaseAction({ logError }) {
  function executer(cuit) {
    const { payments: { entity: { Validator = null } = {} } = {} } = utilities[cuit] || {};

    if (!Validator) {
      logError({
        message: 'payment request entity not found',
        metadata: { cuit },
        filename: __filename,
      });

      throw new PaymentEntityNotFound();
    }

    return Validator;
  }

  return executer;
}

export default getPaymentEntityUsecaseAction;
