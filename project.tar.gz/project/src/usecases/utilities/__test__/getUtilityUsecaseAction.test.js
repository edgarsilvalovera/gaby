import getUtilityUsecaseAction from '../getUtilityUsecaseAction';
import { logError } from '../../../logger';
import { expectCodeThrowsAsync } from '../../../../__test__/expectThrowsAsync';
import { getMockFindByCuitUtilityByFakeResponse } from '../../../../__test__/mocks/models/utility/mocksUtility';
import { spyInstanceUtilityModel } from '../../../../__test__/mocks/models/utility/spysUtility';
import { getFakeResponseFindByCuitUtilityByCuit } from '../../../../__test__/mocks/models/utility/makeFakeResponseFindByCuitUtility';
import { LITORAL_GAS_CUIT } from '../../../../__test__/utilitiesCuitTest';

const parameters = {
  utilityModel: spyInstanceUtilityModel,
  logError,
};

describe('Get Utility By Cuit', () => {
  it('Method getUtilityUsecaseAction() should return a function', () => {
    let executer = getUtilityUsecaseAction(parameters);

    expect(typeof executer).toBe('function');
  });

  it('Method executer() should return a Exception', async () => {
    const cuit = '123';
    const fakeUtility = undefined;

    const mockFindByCuit = getMockFindByCuitUtilityByFakeResponse(fakeUtility);

    const executer = getUtilityUsecaseAction(parameters);

    const method = () => executer(cuit);
    const utilityNotFoundError = 'UT04040';
    await expectCodeThrowsAsync(method, utilityNotFoundError);

    expect(mockFindByCuit).toHaveBeenCalled();
  });

  it('Method executer() should return a Response Api Litoral', async () => {
    let fakeUtility = getFakeResponseFindByCuitUtilityByCuit(LITORAL_GAS_CUIT);

    const mockFindByCuit = getMockFindByCuitUtilityByFakeResponse(fakeUtility);

    const executer = await getUtilityUsecaseAction(parameters);
    const utility = await executer(LITORAL_GAS_CUIT);

    expect(mockFindByCuit).toHaveBeenCalled();
    expect(utility.cuit).toEqual(LITORAL_GAS_CUIT);
  });
});
