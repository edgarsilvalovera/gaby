import * as utilitiesIndex from '..';

describe('Get Utility Usecase Instance', () => {
  it('Method getUtilityUsecaseInstance() should return a function', () => {
    let fakeExecuter = async () => {};

    let fakeGetUtilityUsecaseAction = jest
      .spyOn(utilitiesIndex, 'getUtilityUsecaseInstance')
      .mockImplementation(() => fakeExecuter);

    let getUtilityUsecaseInstance = utilitiesIndex.getUtilityUsecaseInstance();

    expect(fakeGetUtilityUsecaseAction).toHaveBeenCalled();
    expect(typeof getUtilityUsecaseInstance).toBe('function');
  });
});
