import { UtilityNotFound } from '../../exceptions/';

function getUtilityUsecaseAction({ utilityModel, logError }) {
  async function executer(cuit) {
    const utility = await utilityModel.findByCUIT(cuit);
    if (!utility) {
      logError({
        message: 'utility not found when getting balances',
        metadata: { cuit },
        filename: __filename,
      });

      throw new UtilityNotFound();
    }
    return utility;
  }

  return executer;
}

export default getUtilityUsecaseAction;
