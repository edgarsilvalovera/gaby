import getPaymentEntityUsecaseAction from './getPaymentEntityUsecaseAction';
import getUtilityUsecaseAction from './getUtilityUsecaseAction';
import { logError } from '../../logger/';
import UtilityModel from '../../models/UtilityModel';

const getUtilityUsecaseInstance = getUtilityUsecaseAction({
  utilityModel: new UtilityModel(),
  logError,
});

const getPaymentEntityUsecaseInstance = getPaymentEntityUsecaseAction({
  logError,
});

export { getUtilityUsecaseInstance, getPaymentEntityUsecaseInstance };
