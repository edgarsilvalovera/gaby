import { tapiPaymentRequestEntity } from '../../entities/tapi';

function processTapiPaymentUseCaseAction({ processPayment }) {
  async function executer({ requestParams, balanceToPay }) {
    const {
      response: { debts = [], utility, company = {}, operationId },
    } = balanceToPay;

    const {
      headers,
      body: { mainTx },
    } = requestParams;

    const { companyName, companyCode } = company;

    //should get only one balance
    const { amount, debtId, expirationDate } = debts[0] || {};

    // build the request
    const tapiRequest = {
      headers,
      mainTx,
      data: {
        amount,
        debtId,
        operationId,
        expirationDate,
        type: 'service',
        companyName,
        companyCode,
      },
      utility,
    };

    const request = tapiPaymentRequestEntity(tapiRequest);
    const response = await processPayment(request);

    response.response.mainTx = response.response.operation.mainTx; //to adjust to emu response
    response.response.tx = response.response.operation.tx;

    return response;
  }

  return executer;
}

export default processTapiPaymentUseCaseAction;
