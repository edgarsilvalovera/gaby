import { processTapiPaymenUseCaseInstance } from '..';
import { LITORAL_GAS_CUIT } from '../../../../__test__/utilitiesCuitTest';
import { getFakeResponseReadRedisByCuit } from '../../../../__test__/mocks/models/redis/makeFakeResponseReadRedis';
import { nockTapiPayment } from '../../../../__test__/mocks/gateways/tapi/nocks/nocks';
import EMU from '../../../../src/constants/emu';
import { expectCodeThrowsAsync } from '../../../../__test__/expectThrowsAsync';
const { headers } = EMU;

const isTapiRequest = true;
const fakeDataCache = getFakeResponseReadRedisByCuit(LITORAL_GAS_CUIT, isTapiRequest);

describe('Process Tapi Payment Usecase', () => {
  it('should notify payment and return a tapi response', async () => {
    const balanceToPay = JSON.parse(fakeDataCache);

    const data = { debtId: '1', amount: 10 };

    const { mockResponse } = nockTapiPayment({ data });

    const params = {
      requestParams: {
        body: { totalAmount: 10 },
        headers: {
          [headers.mainTx]: 'mainTx',
          [headers.accountId]: 'accountId',
        },
      },
      balanceToPay,
    };

    const { response } = await processTapiPaymenUseCaseInstance(params);

    expect(response).toEqual(expect.objectContaining(mockResponse));
  });

  it('should throw error when cached response is invalid', async () => {
    const params = {
      requestParams: {
        body: { totalAmount: 10 },
        headers: {
          [headers.mainTx]: 'mainTx',
          [headers.accountId]: 'accountId',
        },
      },
      balanceToPay: { response: {} },
    };

    await expectCodeThrowsAsync(() => processTapiPaymenUseCaseInstance(params), 'UT04000');
  });
});
