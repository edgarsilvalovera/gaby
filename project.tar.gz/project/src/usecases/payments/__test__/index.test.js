import * as paymentIndex from '..';

describe('Get Balance ToPay Usecase Instance', () => {
  it('Method getBalanceToPayUsecaseInstance() should return a function', async () => {
    let fakeExecuter = async () => {};

    let fakeGetBalanceToPayUsecaseInstance = jest
      .spyOn(paymentIndex, 'getBalanceToPayUsecaseInstance')
      .mockImplementation(() => fakeExecuter);

    let getBalanceToPayUsecaseAction = paymentIndex.getBalanceToPayUsecaseInstance();

    expect(fakeGetBalanceToPayUsecaseInstance).toHaveBeenCalled();
    expect(typeof getBalanceToPayUsecaseAction).toBe('function');
  });

  it('Method notifyPaymentsUsecaseInstance() should return a function', async () => {
    let fakeExecuter = async () => {};

    let fakeNotifyPaymentsUsecaseInstance = jest
      .spyOn(paymentIndex, 'notifyPaymentsUsecaseInstance')
      .mockImplementation(() => fakeExecuter);

    let notifyPaymentsUsecaseInstance = paymentIndex.notifyPaymentsUsecaseInstance();

    expect(fakeNotifyPaymentsUsecaseInstance).toHaveBeenCalled();
    expect(typeof notifyPaymentsUsecaseInstance).toBe('function');
  });
});
