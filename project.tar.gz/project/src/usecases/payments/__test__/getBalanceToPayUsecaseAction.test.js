import getBalanceToPayUsecaseAction from '../getBalanceToPayUsecaseAction';
import adapters from '../../../adapters/microservices';
import { logError } from '../../../logger/';
import { fakeRequestParamsPayment } from '../../../../__test__/makeFakeRequestParamsPayment';
import { LITORAL_GAS_CUIT } from '../../../../__test__/utilitiesCuitTest';
import { expectCodeThrowsAsync } from '../../../../__test__/expectThrowsAsync';
import { getMockGetBalanceToPay } from '../../../../__test__/getMockGetBalanceToPay';
import { getMockReadRedisByDatCacheJson } from '../../../../__test__/mocks/models/redis/mockRedis';
import { getFakeResponseReadRedisByCuit } from '../../../../__test__/mocks/models/redis/makeFakeResponseReadRedis';

const fakeDataCache = getFakeResponseReadRedisByCuit(LITORAL_GAS_CUIT);
const fakeDataCacheJson = JSON.parse(fakeDataCache);
fakeRequestParamsPayment.body = JSON.parse(fakeRequestParamsPayment.body.body);

const mockReadRedis = getMockReadRedisByDatCacheJson(fakeDataCacheJson);

const parameters = { adapters, logError };

describe('Get Balance To Pay Usecase Action', () => {
  it('Method getBalanceToPayUsecaseAction() should return a function', () => {
    const executer = getBalanceToPayUsecaseAction(parameters);

    expect(typeof executer).toBe('function');
  });

  it('Method executer() should return a Exception CachedBalanceNotFound (404 - NotFound)', async () => {
    const method = () => getMockGetBalanceToPay(fakeRequestParamsPayment);
    const errorMessage = 'UT24042';
    await expectCodeThrowsAsync(method, errorMessage);
    expect(mockReadRedis).toHaveBeenCalled();
  });

  it('Method executer() should return a Data', async () => {
    const balanceId = fakeDataCacheJson.response.balances[0].balanceId;
    fakeRequestParamsPayment.body.balanceId = balanceId;

    const balanceToPay = await getMockGetBalanceToPay(fakeRequestParamsPayment);
    const { response } = balanceToPay;

    expect(mockReadRedis).toHaveBeenCalled();
    expect(response).toHaveProperty('amount');
    expect(response).toHaveProperty('isPayable');
    expect(response).toHaveProperty('concept');
    expect(response).toHaveProperty('dueDate');
    expect(response).toHaveProperty('balanceId');
    expect(response.balanceId).toBe(balanceId);
  });
});
