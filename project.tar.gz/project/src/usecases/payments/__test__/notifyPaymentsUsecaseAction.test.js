import { getPaymentEntityUsecaseInstance } from '../../utilities';
import { parseRequestPayments } from '../../../adapters/parsePayments';
import notifyPaymentsUsecaseAction from '../notifyPaymentsUsecaseAction';
import { LITORAL_GAS_CUIT } from '../../../../__test__/utilitiesCuitTest';
import { fakeRequestParamsPayment } from '../../../../__test__/makeFakeRequestParamsPayment';
import { getMockGetBalanceToPay } from '../../../../__test__/getMockGetBalanceToPay';
import notifyPaymentsService from '../../../gateways/microservices/payments/notifyPaymentsService';
import callAPI from '../../../gateways/microservices/callAPI';
import { getMockCallApiPaymentByCuit } from '../../../../__test__/mocks/gateways/microservices/payments/mocksMicroservicesPayment';
import { getMockReadRedisByDatCacheJson } from '../../../../__test__/mocks/models/redis/mockRedis';
import { getFakeResponseReadRedisByCuit } from '../../../../__test__/mocks/models/redis/makeFakeResponseReadRedis';

const fakeDataCache = getFakeResponseReadRedisByCuit(LITORAL_GAS_CUIT);
const fakeDataCacheJson = JSON.parse(fakeDataCache);

const mockReadRedis = getMockReadRedisByDatCacheJson(fakeDataCacheJson);
const mockCallApiPayment = getMockCallApiPaymentByCuit(LITORAL_GAS_CUIT);

const notifyPaymentsServiceInstance = notifyPaymentsService({
  callAPI,
});
const parameters = {
  getPaymentEntity: getPaymentEntityUsecaseInstance,
  parseRequestPayments,
  notifyPayment: notifyPaymentsServiceInstance,
};

describe('Get Balance To Pay Usecase Action', () => {
  it('Method notifyPaymentsUsecaseAction() should return a function', () => {
    const executer = notifyPaymentsUsecaseAction(parameters);
    expect(typeof executer).toBe('function');
  });

  it('Method executer() should return a Data', async () => {
    const balanceId = fakeDataCacheJson.response.balances[0].balanceId;

    //to don't get the exception CachedBalanceNotFound
    fakeRequestParamsPayment.body = JSON.parse(fakeRequestParamsPayment.body.body);
    fakeRequestParamsPayment.body.balanceId = balanceId;

    const balanceToPay = await getMockGetBalanceToPay(fakeRequestParamsPayment);
    const executer = notifyPaymentsUsecaseAction(parameters);
    const response = await executer({ requestParams: fakeRequestParamsPayment, balanceToPay });

    expect(mockReadRedis).toHaveBeenCalled();
    expect(mockCallApiPayment).toHaveBeenCalled();
    expect(typeof response).toBe('object');
  });
});
