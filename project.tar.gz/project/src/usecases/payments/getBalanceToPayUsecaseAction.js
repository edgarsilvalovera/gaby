import { CachedBalanceNotFound } from '../../exceptions/';

function getBalanceToPayUsecaseAction({ adapters, logError }) {
  async function executer(searchId, balanceId, cachedData) {
    const {
      request: {
        params: { cuit = null },
      },
      response: cachedResponse = {},
    } = cachedData;

    // get the mapper to obtain balances from the cached response
    const { balances: balancesMapper = {} } = adapters[cuit] || {};

    // get balances (reference is due to different responses from microservices)
    const reference = cachedResponse[balancesMapper.msResponse] || cachedResponse;
    const balances = reference[balancesMapper.balances] || [];

    if (balances.length !== 1) {
      const balanceToPay = balances.find(({ balanceId: cachedId }) => balanceId === cachedId);

      if (!balanceToPay) {
        logError({
          message: 'balance to pay not found',
          metadata: { searchId, balanceId, cuit },
          filename: __filename,
        });

        throw new CachedBalanceNotFound();
      }

      // overwrite any balances with the one found
      reference[balancesMapper.balances] = [balanceToPay];
    }

    cachedData.response = parseBalance(cachedResponse, balancesMapper);

    return cachedData;
  }

  // helper to build a plain object of the balance to pay
  function parseBalance(preparedResponse, mapper) {
    let tempData = { ...preparedResponse };

    // due to different responses from microservices
    if (preparedResponse[mapper.msResponse]) {
      tempData = Object.assign(tempData, preparedResponse[mapper.msResponse]);
      delete tempData[mapper.msResponse];
    }

    const [tempBalanceData] = tempData[mapper.balances];
    delete tempData[mapper.balances];

    return { ...tempData, ...tempBalanceData };
  }

  return executer;
}

export default getBalanceToPayUsecaseAction;
