import notifyPaymentsUsecaseAction from './notifyPaymentsUsecaseAction';
import getBalanceToPayUsecaseAction from './getBalanceToPayUsecaseAction';
import adapters from '../../adapters/microservices/';
import { parseRequestPayments } from '../../adapters/parsePayments';
import { getPaymentEntityUsecaseInstance } from '../utilities/';
import notifyPaymentsServiceInstance from '../../gateways/microservices/payments/';
import { processPaymentInstance } from '../../gateways/tapi';
import processTapiPaymentUseCaseAction from './processTapiPaymentUseCaseAction';
import { logError } from '../../logger/';

const getBalanceToPayUsecaseInstance = getBalanceToPayUsecaseAction({
  adapters,
  logError,
});

const notifyPaymentsUsecaseInstance = notifyPaymentsUsecaseAction({
  getPaymentEntity: getPaymentEntityUsecaseInstance,
  parseRequestPayments,
  notifyPayment: notifyPaymentsServiceInstance,
});

const processTapiPaymenUseCaseInstance = processTapiPaymentUseCaseAction({
  processPayment: processPaymentInstance,
});

export {
  getBalanceToPayUsecaseInstance,
  notifyPaymentsUsecaseInstance,
  processTapiPaymenUseCaseInstance,
};
