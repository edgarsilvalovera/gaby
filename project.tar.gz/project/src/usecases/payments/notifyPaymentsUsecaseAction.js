import EMU from '../../constants/emu';

function notifyPaymentsUsecaseAction({ getPaymentEntity, parseRequestPayments, notifyPayment }) {
  const {
    paymentMethods: { tap },
    headers: { mainTx: mainTxHeader, accountId: accountIdHeader },
  } = EMU;

  async function executer({ requestParams, balanceToPay }) {
    // totalAmount is received only to validate the cached amount
    // paymentMethod is set as account balance ("tap") in the interoperability
    // pspId & mainTx are only received in the interoperability

    const {
      body: { totalAmount, paymentMethod = tap, pspId = null, mainTx = null },
      headers,
    } = requestParams;

    // cached data (keys are in camel case, notice "baseUrl")
    const {
      request: {
        params: { cuit, qrType },
        baseUrl: baseURL,
      },
      response: cachedResponse,
    } = balanceToPay;

    // build the request
    const newRequestParams = {
      queryParams: { qrType, cuit, pspId },
      body: {
        ...parseRequestPayments({ ...cachedResponse, paymentMethod }, cuit),
        totalAmount,
      },
      headers: {
        [mainTxHeader]: mainTx || headers[mainTxHeader],
        [accountIdHeader]: headers[accountIdHeader],
      },
      baseURL,
      utility: cachedResponse.utility,
    };

    const Validator = getPaymentEntity(cuit);
    const validatedRequestParams = new Validator(newRequestParams);

    return notifyPayment(validatedRequestParams);
  }

  return executer;
}

export default notifyPaymentsUsecaseAction;
