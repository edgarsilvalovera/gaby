import { config } from 'config';
import sendSqsMessageInstance from './sendSqsMessage';
import { logInfo } from '../../logger/';
import Aws from '../../gateways/aws';

const { fiatQueueURL } = config;

const sendSqsMessage = sendSqsMessageInstance({
  dependencies: {
    logInfo,
    Aws,
    queueUrl: fiatQueueURL,
  },
});

export { sendSqsMessage };
