import { sendSqsMessageEntity } from '../../entities/sqsMessage/';

const instanceGetDefault =
  ({ dependencies }) =>
  async ({ params }) => {
    const { Aws, logInfo, queueUrl } = dependencies;
    const { data, delaySeconds = 0, tx = '-' } = params;
    //body only accepts strings
    const messageBody = JSON.stringify(data);
    const prepareParams = sendSqsMessageEntity({
      delaySeconds,
      messageBody,
      queueUrl,
    });

    logInfo({
      message: 'sending sqs message',
      tx,
      metadata: prepareParams,
    });

    const response = await Aws.sendMessageQueues({
      params: prepareParams,
    });

    return Object.freeze(response);
  };

export default instanceGetDefault;
