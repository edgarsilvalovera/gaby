import { config } from 'config';
import instanceGetDefault from '../sendSqsMessage';
import { logInfo } from '../../../logger/index';
import { fakeRequestParamsPayment } from '../../../../__test__/makeFakeRequestParamsPayment';
import { getMockSendSqsMessageSqs } from '../../../../__test__/mocks/gateways/aws/sqs/mocksAwsSqs';

const { fiatQueueURL } = config;

const mockSendSqsMessage = getMockSendSqsMessageSqs();

const dependencies = {
  dependencies: {
    logInfo,
    Aws: mockSendSqsMessage,
    queueUrl: fiatQueueURL,
  },
};

describe('Send Sqs Message', () => {
  const sendSqsMessage = instanceGetDefault(dependencies);

  it('Method notifyPaymentsUsecaseAction() should return a function', () => {
    expect(typeof sendSqsMessage).toBe('function');
  });

  it('Method notifyPaymentsUsecaseAction() should return a data', async () => {
    const { mainTx } = fakeRequestParamsPayment;

    let response = await sendSqsMessage({
      params: { data: { qrIdTrx: mainTx, status: 'success' } },
    });

    expect(response).toBe('success');
  });
});
