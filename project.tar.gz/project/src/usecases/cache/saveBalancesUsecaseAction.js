function saveBalancesUsecaseAction({ balancesCacheModel }) {
  async function executer({ searchId, ...data }) {
    return await balancesCacheModel.save(searchId, data);
  }

  return executer;
}

export default saveBalancesUsecaseAction;
