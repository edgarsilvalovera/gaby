function getBalancesUsecaseAction({ balancesCacheModel }) {
  async function executer(searchId) {
    return balancesCacheModel.read(searchId);
  }

  return executer;
}

export default getBalancesUsecaseAction;
