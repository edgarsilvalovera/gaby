import getBalancesUsecaseAction from './getBalancesUsecaseAction';
import saveBalancesUsecaseAction from './saveBalancesUsecaseAction';
import BalancesCacheModel from '../../models/BalancesCacheModel';

const saveBalancesUsecaseInstance = saveBalancesUsecaseAction({
  balancesCacheModel: new BalancesCacheModel(),
});

const getBalancesUsecaseInstance = getBalancesUsecaseAction({
  balancesCacheModel: new BalancesCacheModel(),
});

export { saveBalancesUsecaseInstance, getBalancesUsecaseInstance };
