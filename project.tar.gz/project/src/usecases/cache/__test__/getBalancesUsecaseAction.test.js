import { getMockBalancesCacheModel } from '../../../../__test__/mocks/models/balanceCache/mocksBalanceCache';
import { getFakeResponseReadRedisByCuit } from '../../../../__test__/mocks/models/redis/makeFakeResponseReadRedis';
import { getMockReadRedisByDatCacheJson } from '../../../../__test__/mocks/models/redis/mockRedis';
import { FAKE_SEARCH_ID } from '../../../../__test__/utilFakeId';
import { LITORAL_GAS_CUIT } from '../../../../__test__/utilitiesCuitTest';
import getBalancesUsecaseAction from '../getBalancesUsecaseAction';

const fakeDataCache = getFakeResponseReadRedisByCuit(LITORAL_GAS_CUIT);

const mockReadRedis = getMockReadRedisByDatCacheJson(fakeDataCache);

const parametersBalancesUsecaseAction = {
  balancesCacheModel: getMockBalancesCacheModel(),
};

describe('Get Balances Usecase Action', () => {
  it('Method saveBalancesUsecaseAction() should return a function', () => {
    const executer = getBalancesUsecaseAction(parametersBalancesUsecaseAction);

    expect(typeof executer).toBe('function');
  });

  it('Method executer() should return a Data', async () => {
    const executer = getBalancesUsecaseAction(parametersBalancesUsecaseAction);
    const response = await executer(FAKE_SEARCH_ID);

    expect(mockReadRedis).toHaveBeenCalled();
    expect(response).toEqual(fakeDataCache);
  });
});
