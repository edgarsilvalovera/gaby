import { getMockBalancesCacheModel } from '../../../../__test__/mocks/models/balanceCache/mocksBalanceCache';
import {
  fakeResponseBalance,
  getFakeResponseReadRedisByCuit,
} from '../../../../__test__/mocks/models/redis/makeFakeResponseReadRedis';
import { getMockSaveRedisByDatCacheJson } from '../../../../__test__/mocks/models/redis/mockRedis';
import { GASNOR_CUIT, LITORAL_GAS_CUIT } from '../../../../__test__/utilitiesCuitTest';
import saveBalancesUsecaseAction from '../saveBalancesUsecaseAction';

const fakeDataCache = getFakeResponseReadRedisByCuit(LITORAL_GAS_CUIT);
const fakeDataCacheJson = JSON.parse(fakeDataCache);
fakeDataCacheJson.request.params.cuit = GASNOR_CUIT;

const mockSaveRedis = getMockSaveRedisByDatCacheJson(fakeDataCacheJson);

const parametersBalancesUsecaseAction = {
  balancesCacheModel: getMockBalancesCacheModel(),
};

describe('Save Balances Usecase Action', () => {
  it('Method saveBalancesUsecaseAction() should return a function', () => {
    const executer = saveBalancesUsecaseAction(parametersBalancesUsecaseAction);
    expect(typeof executer).toBe('function');
  });

  it('Method executer() should return a Data', async () => {
    const { parsedResponse, originalResponse } = fakeResponseBalance;

    const parametersExecuter = {
      searchId: parsedResponse.balancesInfo.searchId,
      request: {
        params: {
          cuit: GASNOR_CUIT,
        },
      },
      response: originalResponse,
    };

    const executer = saveBalancesUsecaseAction(parametersBalancesUsecaseAction);
    const response = await executer(parametersExecuter);

    expect(mockSaveRedis).toHaveBeenCalled();
    expect(response).toHaveProperty('response');
    expect(response.response).toHaveProperty('balances');
  });
});
