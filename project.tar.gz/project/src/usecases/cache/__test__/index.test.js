import * as cacheIndex from '..';

describe('Save Balances Usecase Instance', () => {
  it('Method saveBalancesUsecaseInstance() should return a function', async () => {
    let fakeExecuter = async () => {};

    let fakeSaveBalancesUsecaseInstance = jest
      .spyOn(cacheIndex, 'saveBalancesUsecaseInstance')
      .mockImplementation(() => fakeExecuter);

    let saveBalancesUsecaseInstance = cacheIndex.saveBalancesUsecaseInstance();

    expect(fakeSaveBalancesUsecaseInstance).toHaveBeenCalled();
    expect(typeof saveBalancesUsecaseInstance).toBe('function');
  });

  it('Method getBalancesUsecaseInstance() should return a function', async () => {
    let fakeExecuter = async () => {};

    let fakeGetBalancesUsecaseInstance = jest
      .spyOn(cacheIndex, 'getBalancesUsecaseInstance')
      .mockImplementation(() => fakeExecuter);

    let geteBalancesUsecaseInstance = cacheIndex.getBalancesUsecaseInstance();

    expect(fakeGetBalancesUsecaseInstance).toHaveBeenCalled();
    expect(typeof geteBalancesUsecaseInstance).toBe('function');
  });
});
