import camelcaseKeys from 'camelcase-keys';
import snakecaseKeys from 'snakecase-keys';

function keysToCamel(hash) {
  return hash && camelcaseKeys(hash, { deep: true });
}

function keysToSnake(hash) {
  return hash && snakecaseKeys(hash, { deep: true });
}

function keysToPascal(hash) {
  return hash && camelcaseKeys(hash, { deep: true, pascalCase: true });
}

export { keysToCamel, keysToSnake, keysToPascal };
