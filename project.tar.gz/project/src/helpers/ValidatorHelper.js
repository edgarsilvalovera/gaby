import { DEFAULT_ERRORS } from '../constants/defaultErrors';

class ValidatorHelper {
  constructor() {
    this.errors = DEFAULT_ERRORS;
  }

  isValidString(param) {
    const { data, field, msg, empty } = this.defaultParams(param);

    if (empty && !data && typeof data !== 'number') {
      return data;
    }

    const validate = typeof data === 'string';

    if (!validate || data.trim() === '') {
      const { text, name } = this.errors.invalidString({ field, msg });
      this.customException({ text, name });
    }

    return data;
  }

  isValidNumber(param) {
    const { data, field, msg, empty } = this.defaultParams(param);
    const validate = typeof data === 'number' || (!data && empty);

    if (!validate) {
      const { text, name } = this.errors.invalidNumber({ field, msg });
      this.customException({ text, name });
    }
    return data;
  }

  defaultParams(param) {
    const keys = Object.keys(param);
    let field = keys[0];
    let msg = null;
    let data = param[keys[0]];
    let empty = false;

    if (keys.length > 1) {
      const {
        data: dataField = field,
        msg: errorMsg = msg,
        field: fieldName = data,
        empty: emptyOption = empty,
      } = param;
      field = fieldName;
      msg = errorMsg;
      data = dataField;
      empty = emptyOption;
    }
    return { data, field, msg, empty };
  }

  customException({ text, name }) {
    const error = new Error(text);
    error.code = name;
    error.message = text;
    throw error;
  }
}

export default ValidatorHelper;
