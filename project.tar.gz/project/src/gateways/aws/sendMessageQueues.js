const sendMessageQueues =
  (dependencies) =>
  async ({ params }) => {
    const { SqsAws, keysToPascal } = dependencies;

    const { delaySeconds, messageAttributes, messageBody, queueUrl } = params;

    const MessageAttributes = keysToPascal({ ...messageAttributes });

    const sqsParams = {
      DelaySeconds: delaySeconds,
      MessageAttributes,
      MessageBody: messageBody,
      QueueUrl: queueUrl,
    };

    return SqsAws.sendMessage(sqsParams).promise();
  };

export default sendMessageQueues;
