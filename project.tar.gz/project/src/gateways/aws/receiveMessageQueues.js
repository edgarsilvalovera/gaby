const receiveMessageQueues =
  (dependencies) =>
  async ({ params }) => {
    const { SqsAws } = dependencies;

    const {
      attributeNames,
      maxNumberOfMessages,
      messageAttributeNames,
      visibilityTimeout,
      waitTimeSeconds,
      queueUrl,
    } = params;

    const sqsParams = {
      AttributeNames: attributeNames,
      MaxNumberOfMessages: maxNumberOfMessages,
      MessageAttributeNames: messageAttributeNames,
      VisibilityTimeout: visibilityTimeout,
      WaitTimeSeconds: waitTimeSeconds,
      QueueUrl: queueUrl,
    };
    return SqsAws.receiveMessage(sqsParams).promise();
  };

export default receiveMessageQueues;
