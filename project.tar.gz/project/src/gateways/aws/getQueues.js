const getQueues =
  (dependencies) =>
  async ({ params }) => {
    const { SqsAws } = dependencies;

    const { maxResults = 1000, nextToken = null, queueNamePrefix = null } = params;
    const sqsParams = {
      MaxResults: maxResults,
      NextToken: nextToken,
      QueueNamePrefix: queueNamePrefix,
    };
    return SqsAws.listQueues(sqsParams).promise();
  };

export default getQueues;
