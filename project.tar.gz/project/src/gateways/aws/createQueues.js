const createQueues =
  (dependencies) =>
  async ({ params }) => {
    const { SqsAws } = dependencies;
    const {
      queueName,
      attributes: { delaySeconds, messageRetentionPeriod },
    } = params;

    const sqsParams = {
      QueueName: queueName,
      Attributes: {
        DelaySeconds: delaySeconds,
        MessageRetentionPeriod: messageRetentionPeriod,
      },
    };
    return SqsAws.createQueue(sqsParams).promise();
  };

export default createQueues;
