const deleteQueues =
  (dependencies) =>
  async ({ params }) => {
    const { SqsAws } = dependencies;

    const { queueUrl } = params;
    const sqsParams = {
      QueueUrl: queueUrl,
    };

    return SqsAws.deleteQueue(sqsParams).promise();
  };

export default deleteQueues;
