const deleteMessageQueues =
  (dependencies) =>
  async ({ params }) => {
    const { SqsAws } = dependencies;

    const { receiptHandle, queueUrl } = params;
    const sqsParams = {
      ReceiptHandle: receiptHandle,
      QueueUrl: queueUrl,
    };

    const deleteMessage = await SqsAws.deleteMessage(sqsParams).promise();

    return deleteMessage;
  };

export default deleteMessageQueues;
