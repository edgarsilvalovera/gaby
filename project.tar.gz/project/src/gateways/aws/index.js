import { config } from 'config';
import sendMessageQueues from './sendMessageQueues';
import { keysToPascal } from '../../helpers/keyParsers';
import * as AWS from 'aws-sdk';

const { sqsTestEndpoint, env = 'dev' } = config;

AWS.config.update({ region: 'us-east-1' });

const configAws =
  env === 'test'
    ? {
        endpoint: sqsTestEndpoint,
        region: 'us-east-1',
        apiVersion: '2012-11-05',
        accessKeyId: 'foo',
        secretAccessKey: 'bar',
      }
    : { apiVersion: '2012-11-05' };

const SqsAws = new AWS.SQS(configAws);

const sendMessageQueuesInstance = sendMessageQueues({ SqsAws, keysToPascal });

const Aws = {
  sendMessageQueues: sendMessageQueuesInstance,
};

export default Aws;
