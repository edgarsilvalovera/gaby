import { checkBillInstance, processPaymentInstance } from '..';
import { INTERNAL_SERVER_ERROR } from 'http-status';
import { expectCodeThrowsAsync } from '../../../../__test__/expectThrowsAsync';
import {
  nockTapiBalance,
  nockTapiBalanceError,
  nockTapiPayment,
  nockTapiPaymentError,
} from '../../../../__test__/mocks/gateways/tapi/nocks/nocks';

describe('check bill gateway', () => {
  it('Get Tapi Balance  OK', async () => {
    const data = { companyCode: '1', modalityId: 'qr', queryData: { debtIdentifier: '1' } };

    const { mockResponse } = nockTapiBalance({ data });

    const { response } = await checkBillInstance({ utility: 'TAPI', data });

    expect(response).toEqual(expect.objectContaining(mockResponse));
  });

  it(`Get Balance Tapi Error ${INTERNAL_SERVER_ERROR}`, async () => {
    nockTapiBalanceError();

    const errorMessage = 'UT95000';

    await expectCodeThrowsAsync(() => checkBillInstance({ utility: 'TAPI' }), errorMessage);
  });
});

describe('process payment gateway', () => {
  it('processes payments OK', async () => {
    const data = { debtId: '1', amount: 10 };

    const { mockResponse } = nockTapiPayment({ data });

    // remove field in apiCall method
    const { response } = await processPaymentInstance({ utility: 'TAPI', data });

    expect(response).toEqual(expect.objectContaining(mockResponse));
  });

  it(`process payment Tapi Error ${INTERNAL_SERVER_ERROR}`, async () => {
    nockTapiPaymentError({});

    const errorMessage = 'UT95000';

    await expectCodeThrowsAsync(() => processPaymentInstance({ utility: 'TAPI' }), errorMessage);
  });
});
