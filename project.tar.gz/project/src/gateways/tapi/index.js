import processPayment from './processPayment';
import checkBill from './checkBill';
import callAPI from '../microservices/callAPI';
import createException from '../../exceptions/factory/createException';

export const processPaymentInstance = processPayment({
  callAPI,
  createException,
});

export const checkBillInstance = checkBill({
  callAPI,
  createException,
});
