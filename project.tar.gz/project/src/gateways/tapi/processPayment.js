import TAPI from '../../constants/tapi';

function processPayment({ callAPI, createException }) {
  const {
    services: {
      payments: { name: service, endpoint: paymentsURL },
      baseURL,
    },
  } = TAPI;

  async function executer({ utility, headers, data, queryParams = null }) {
    const requestParams = {
      url: paymentsURL,
      method: 'post',
      baseURL,
      headers,
      params: queryParams,
      data,
      utility,
    };

    return callAPI(requestParams).catch((error) => {
      throw createException(service, utility, error);
    });
  }

  return executer;
}

export default processPayment;
