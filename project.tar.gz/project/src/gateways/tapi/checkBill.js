import TAPI from '../../constants/tapi';

function checkBill({ callAPI, createException }) {
  const {
    services: {
      baseURL,
      balances: { name: service, endpoint: balancesURL },
    },
  } = TAPI;

  async function executer({ utility, headers, data = {} }) {
    const requestParams = {
      url: balancesURL,
      method: 'post',
      baseURL,
      headers,
      data,
      utility,
    };

    return callAPI(requestParams).catch((error) => {
      throw createException(service, utility, error);
    });
  }

  return executer;
}

export default checkBill;
