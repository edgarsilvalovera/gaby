import getBalancesService from './getBalancesService';
import callAPI from '../callAPI';

const getBalancesServiceInstance = getBalancesService({
  callAPI,
});

export default getBalancesServiceInstance;
