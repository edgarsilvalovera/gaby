import getBalancesService from '../getBalancesService';
import { fakeValidatedRequestParams } from '../../../../../__test__/makeFakeRequestParamsBalance';
import { INTERNAL_SERVER_ERROR } from 'http-status';
import { expectCodeThrowsAsync } from '../../../../../__test__/expectThrowsAsync';
import { LITORAL_GAS_CUIT } from '../../../../../__test__/utilitiesCuitTest';
import * as microservicesCallApi from '../../callAPI';
import { getMockCallApiBalanceByFakeResponse } from '../../../../../__test__/mocks/gateways/microservices/balances/mocksMicroservicesBalance';
import { getFakeResponseCallApiBalanceByCuit } from '../../../../../__test__/mocks/gateways/microservices/balances/makeFakeResponseCallApiBalance';

describe('Get Balances Service', () => {
  it('Get Balance Litoral OK', async () => {
    let fakeResponseApi = getFakeResponseCallApiBalanceByCuit(LITORAL_GAS_CUIT);

    const mockCallApi = getMockCallApiBalanceByFakeResponse(fakeResponseApi);

    let executer = getBalancesService({ callAPI: microservicesCallApi.default });
    let balance = await executer(fakeValidatedRequestParams);

    expect(mockCallApi).toHaveBeenCalled();
    expect(balance).toEqual(fakeResponseApi);
  });

  it(`Get Balance Litoral Error ${INTERNAL_SERVER_ERROR}`, async () => {
    const fakeResponseApi = new Error();
    const mockCallApi = getMockCallApiBalanceByFakeResponse(fakeResponseApi);

    let executer = getBalancesService({ callAPI: microservicesCallApi.default });

    let method = () => executer(fakeValidatedRequestParams);
    let errorMessage = 'UT05000';
    await expectCodeThrowsAsync(method, errorMessage);

    expect(mockCallApi).toHaveBeenCalled();
  });
});
