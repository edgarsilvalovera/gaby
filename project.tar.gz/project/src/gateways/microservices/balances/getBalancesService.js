import EMU from '../../../constants/emu';
import createException from '../../../exceptions/factory/createException';

function getBalancesService({ callAPI }) {
  const {
    services: {
      balances: { name: service, endpoint: balancesURL },
    },
  } = EMU;

  async function executer({ utility, baseURL, headers, urlParams, queryParams }) {
    const requestParams = {
      url: `${balancesURL}/${urlParams.document}`,
      method: 'get',
      baseURL,
      headers,
      params: queryParams,
      utility,
    };
    return callAPI(requestParams).catch((error) => {
      throw createException(service, utility, error);
    });
  }

  return executer;
}

export default getBalancesService;
