import EMU from '../../../constants/emu';
import createException from '../../../exceptions/factory/createException';

function notifyPaymentsService({ callAPI }) {
  const {
    services: {
      payments: { name: service, endpoint: paymentsURL },
    },
  } = EMU;

  async function executer({ utility, baseURL, headers, body, queryParams }) {
    const requestParams = {
      url: paymentsURL,
      method: 'post',
      baseURL,
      headers,
      params: queryParams,
      data: body,
      utility,
    };

    return callAPI(requestParams).catch((error) => {
      throw createException(service, utility, error);
    });
  }

  return executer;
}

export default notifyPaymentsService;
