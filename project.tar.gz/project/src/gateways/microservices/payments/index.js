import notifyPaymentsService from './notifyPaymentsService';
import callAPI from '../callAPI';

const notifyPaymentsServiceInstance = notifyPaymentsService({
  callAPI,
});

export default notifyPaymentsServiceInstance;
