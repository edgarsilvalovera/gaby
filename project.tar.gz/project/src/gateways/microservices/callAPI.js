import axios from 'axios';
import EMU from '../../constants/emu';
import { keysToCamel, keysToSnake } from '../../helpers/keyParsers';
import { logRequest, logResponse, logError } from '../../logger/';

const {
  request: { defaultTimeout },
} = EMU;

async function callAPI({ globalStartTime = null, ...restRequestParams }) {
  const startTime = globalStartTime || process.hrtime();

  const {
    utility,
    mainTx,
    tx,
    accountId,
    url,
    method,
    baseURL,
    headers = null,
    params: rawParams = null,
    data: rawData = null,
    timeout = defaultTimeout,
  } = restRequestParams;

  const params = keysToSnake(rawParams);
  const data = keysToSnake(rawData);

  // build request options for axios
  const requestOptions = {
    url,
    method,
    baseURL,
    headers,
    params,
    data,
    timeout,
  };

  const logData = { utility, mainTx, tx, accountId, startTime, filename: __filename };

  logRequest({
    message: `request to MS-${utility}`,
    ...logData,
    req: { body: data, params, method, originalUrl: url },
  });

  const { status, data: response } = await axios(requestOptions).catch((responseError) => {
    logError({
      message: `something went wrong in MS-${utility} => ${responseError}`,
      ...logData,
      metadata: { ...responseError },
    });

    // bubble the error up
    throw responseError;
  });

  logResponse({
    message: `raw response received from MS-${utility}`,
    ...logData,
    status,
    metadata: response,
  });

  return {
    request: keysToCamel(requestOptions),
    response: { utility, ...keysToCamel(response) },
    status,
  };
}

export default callAPI;
