export const DEFAULT_ERRORS = {
  invalidString: ({ msg, field = 'invalidString' }) => {
    return {
      text: msg || `Error: ${field} must have a valid string.`,
      name: `${field}Error`,
    };
  },
  invalidNumber: ({ msg, field = 'invalidNumber' }) => {
    return {
      text: msg || `Error: ${field} must have a valid Number.`,
      name: `${field}Error`,
    };
  },
};
