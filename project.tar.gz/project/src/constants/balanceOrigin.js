export const ORIGIN = Object.freeze({
  TAPI: 'TAPI',
  UTILITIES: 'UT',
});
