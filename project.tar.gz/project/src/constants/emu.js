const EMU = Object.freeze({
  paymentMethods: {
    tap: 'tap',
    debit: 'debit',
    credit: 'credit',
  },
  qrTypes: {
    iep: 'iep',
    tap: 'service',
  },
  headers: {
    mainTx: 'x-main-tx',
    accountId: 'x-account-id',
  },
  request: {
    defaultTimeout: 30000,
  },
  services: {
    balances: {
      name: 'balances',
      endpoint: '/balances',
    },
    payments: {
      name: 'payments',
      endpoint: '/payments',
    },
    files: {
      name: 'files',
      endpoint: '/files',
    },
    vouchers: {
      name: 'vouchers',
      endpoint: '/vouchers',
    },
  },
  redis: {
    // 3 days in seconds => 3 x 24 x 60 x 60
    expiration: 259200,
  },
});

export default EMU;
