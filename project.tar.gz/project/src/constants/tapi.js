import { config } from 'config';

const {
  tapi: { baseURL },
} = config;

const TAPI = Object.freeze({
  headers: {
    mainTx: 'x-main-tx',
    accountId: 'x-account-id',
  },
  services: {
    baseURL,
    balances: {
      name: 'balances',
      endpoint: '/check-bill',
    },
    payments: {
      name: 'payments',
      endpoint: '/process-payment',
    },
  },
});

export default TAPI;
