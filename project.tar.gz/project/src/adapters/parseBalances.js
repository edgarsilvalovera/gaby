import utilities from './microservices/';
import { BalancesResponse } from '../contracts/';
import { BalancesMapperNotFound } from '../exceptions/';
import { logError } from '../logger/';
import { TapiBalanceResponse } from '../contracts/TapiBalanceResponse';

function parseBalances({ data, cuit, tapiBalance = false }) {
  const parsedResponse = tapiBalance
    ? new TapiBalanceResponse({ data })
    : parseUtilityBalance({ data, cuit });
  return {
    parsedResponse,
    originalResponse: data,
  };
}

const parseUtilityBalance = ({ data, cuit }) => {
  const { balances: balancesMapper = null } = utilities[cuit] || {};

  if (!balancesMapper) {
    logError({
      message: 'balances mapper not found',
      metadata: { cuit },
      filename: __filename,
    });

    throw new BalancesMapperNotFound();
  }

  const parsedResponse = new BalancesResponse({
    data,
    mapper: balancesMapper,
  });

  // assign balance ids to the original response
  parsedResponse.balancesInfo.balances.forEach(({ balanceId, index }) => {
    // due to different responses from microservices
    const reference = data[balancesMapper.msResponse] || data;

    reference[balancesMapper.balances][index].balanceId = balanceId;
  });

  return parsedResponse;
};

export default parseBalances;
