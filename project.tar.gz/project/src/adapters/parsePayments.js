import utilities from './microservices/';
import { PaymentsResponse } from '../contracts/';
import { PaymentsMapperNotFound } from '../exceptions/';
import { logError } from '../logger/';

function parseRequestPayments(data, cuit) {
  const mapper = getMapper(cuit, 'request');

  return Object.keys(mapper).reduce((result, property) => {
    result[mapper[property]] = data[property];
    return result;
  }, {});
}

const tapiMapper = {
  msResponse: 'operation',
  transactionId: 'operationId',
  paymentId: 'transactionId',
  message: 'message',
  code: 'code',
};

function parseResponsePayments({ data, cuit, tapiOrigin = false }) {
  const mapper = tapiOrigin ? tapiMapper : getMapper(cuit, 'response');

  return new PaymentsResponse({ data, mapper });
}

function getMapper(cuit, parser) {
  const { payments: { [parser]: paymentsMapper = null } = {} } = utilities[cuit] || {};

  if (!paymentsMapper) {
    logError({
      message: `${parser} payments mapper not found`,
      metadata: { cuit },
      filename: __filename,
    });

    throw new PaymentsMapperNotFound(parser);
  }

  return paymentsMapper;
}

export { parseRequestPayments, parseResponsePayments };
