import { NAME_UTILITIES, SCPL_CUIT } from '../../../__test__/utilitiesCuitTest';
import { NOT_FOUND } from 'http-status';
import { expectCodeThrowsAsync } from '../../../__test__/expectThrowsAsync';
import { PaymentsInfo } from '../../contracts';
import { parseResponsePayments } from '../parsePayments';
import { getFakeResponseCallApiPaymentByCuit } from '../../../__test__/mocks/gateways/microservices/payments/makeFakeResponseCallApiPayment';
import { makeFakePayment } from '../../../__test__/mocks/gateways/tapi/payments/makeFakePayment';

const nameUtilitiesToTest = Object.keys(NAME_UTILITIES).filter((cuit) => cuit != SCPL_CUIT);

describe('Parse Payment', () => {
  const testUtilityByCuit = (cuit) => {
    const data = getFakeResponseCallApiPaymentByCuit(cuit);

    const response = parseResponsePayments({ data, cuit });

    defaultExpect(response);
  };

  it(`Should return a Exception PaymentsMapperNotFound (${NOT_FOUND})`, async () => {
    let data = {};
    let cuit = '';

    let method = () => parseResponsePayments({ data, cuit });
    let errorMessage = 'UT34041';

    await expectCodeThrowsAsync(method, errorMessage);
  });

  for (const cuitUtility of nameUtilitiesToTest) {
    it(`Should return a Response Api of ${NAME_UTILITIES[cuitUtility]}`, () => {
      testUtilityByCuit(cuitUtility);
    });
  }

  it('should parse tapi payment without errors', () => {
    const data = makeFakePayment();
    const response = parseResponsePayments({ data, tapiOrigin: true });

    const expectedResponse = {
      paymentsInfo: {
        transactionId: data.operation.operationId,
        paymentId: data.operation.transactionId,
        message: null,
        code: null,
      },
    };

    defaultExpect(response);
    expect(expectedResponse).toEqual(response);
  });

  const defaultExpect = (response) => {
    expect(response).toHaveProperty('mainTx');
    expect(response).toHaveProperty('tx');
    expect(response).toHaveProperty('paymentsInfo');
    expect(response.paymentsInfo).toBeInstanceOf(PaymentsInfo);
  };
});
