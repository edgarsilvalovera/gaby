import parseBalances from '../parseBalances';
import { NAME_UTILITIES } from '../../../__test__/utilitiesCuitTest';
import { NOT_FOUND } from 'http-status';
import { expectCodeThrowsAsync } from '../../../__test__/expectThrowsAsync';
import { BalancesResponse } from '../../contracts';
import { getFakeResponseCallApiBalanceByCuit } from '../../../__test__/mocks/gateways/microservices/balances/makeFakeResponseCallApiBalance';
import { makeFakeBalance } from '../../../__test__/mocks/gateways/tapi/balances/makeFakeBalance';
import { TapiBalanceResponse } from '../../contracts/TapiBalanceResponse';

describe('Parse Balances', () => {
  const testUtilityByCuit = (cuit) => {
    const data = getFakeResponseCallApiBalanceByCuit(cuit);

    const response = parseBalances({ data, cuit });

    defaultExpect(response);

    expect(response.parsedResponse).toBeInstanceOf(BalancesResponse);
  };

  it(`Should return a Exception BalancesMapperNotFound (${NOT_FOUND})`, async () => {
    let data = {};
    let cuit = '';

    let method = () => parseBalances({ data, cuit });
    let errorMessage = 'UT24041';

    await expectCodeThrowsAsync(method, errorMessage);
  });

  for (const cuitUtility in NAME_UTILITIES) {
    it(`Should return a Response Api of ${NAME_UTILITIES[cuitUtility]}`, () => {
      testUtilityByCuit(cuitUtility);
    });
  }

  it('should parse tapi balance without errors', () => {
    const data = makeFakeBalance();

    const response = parseBalances({ data, tapiBalance: true });

    defaultExpect(response);

    expect(response.parsedResponse).toBeInstanceOf(TapiBalanceResponse);
  });
});

function defaultExpect(response) {
  expect(response).toHaveProperty('parsedResponse');
  expect(response).toHaveProperty('originalResponse');
}
