import { SCPLPaymentsRequestValidator } from '../../entities/';
const balances = {
  msResponse: null,
  paymentDocument: 'paymentDocument',
  customerName: null,
  customerAddress: null,
  balances: 'balances',
  balancesDetail: {
    amount: 'amount',
    isPayable: null,
    concept: null,
    message: null,
    dueDate: 'dueDate',
  },
};
const payments = {
  // keys are part of the cached microservice response
  // values are part of the request to the microservice
  // paymentMethod (in request) come from the payment request
  request: {
    paymentDocument: 'paymentDocument',
    amount: 'amount',
    paymentReference: 'paymentReference',
    paymentMethod: 'paymentMethod',
    barCode: 'barCode',
    dueDate: 'dueDate',
  },
  entity: {
    Validator: SCPLPaymentsRequestValidator,
  },
  // keys are part of the emu common structure for payments
  // values are part of the microservice response
  response: {
    msResponse: 'payment',
    paymentId: 'paymentId',
    transactionId: 'paymentTransactionId',
    message: null,
    code: null,
  },
};

exports.utility = {
  30545726722: {
    balances,
    payments,
  },
};
