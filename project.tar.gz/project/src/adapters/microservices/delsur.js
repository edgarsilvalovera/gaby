// delsur is part of the camuzzi group
import { CamuzziPaymentsRequestValidator } from '../../entities/';

// keys are part of the emu common structure for balances
// values are part of the microservice response
const balances = {
  msResponse: null,
  paymentDocument: 'accountNumber',
  customerName: null,
  customerAddress: null,
  balances: 'balances',
  balancesDetail: {
    amount: 'amount',
    isPayable: null,
    concept: null,
    message: null,
    dueDate: null,
  },
};

const payments = {
  // keys are part of the cached microservice response
  // values are part of the request to the microservice
  // paymentMethod (in request) come from the payment request
  request: {
    cuit: 'cuit',
    accountNumber: 'accountNumber',
    amount: 'amount',
    invoices: 'invoices',
    paymentMethod: 'paymentType',
  },
  entity: {
    Validator: CamuzziPaymentsRequestValidator,
  },
  // keys are part of the emu common structure for payments
  // values are part of the microservice response
  response: {
    msResponse: null,
    paymentId: 'paymentId',
    transactionId: 'transactionId',
    message: null,
    code: null,
  },
};

exports.utility = {
  30657864427: {
    balances,
    payments,
  },
};
