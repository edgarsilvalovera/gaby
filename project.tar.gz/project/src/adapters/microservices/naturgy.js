import { NaturgyPaymentsRequestValidator } from '../../entities/';

// keys are part of the emu common structure for balances
// values are part of the microservice response (microservice name is "beyond")
const balances = {
  msResponse: null,
  customerName: 'clientName',
  customerAddress: null,
  balances: 'balances',
  paymentDocument: 'paymentDocument',
  balancesDetail: {
    amount: 'amount',
    isPayable: null,
    concept: null,
    message: null,
    dueDate: 'duedate',
  },
};

const payments = {
  // keys are part of the cached microservice response
  // values are part of the request to the microservice
  // paymentMethod (in request) come from the payment request
  request: {
    amount: 'amount',
    clientId: 'clientId',
    paymentDocument: 'paymentDocument',
    concept: 'concept',
    documentType: 'documentType',
    year: 'year',
    bimester: 'bimester',
    paymentMethod: 'paymentMethod',
    semiVoucher: 'semiVoucher',
  },
  entity: {
    Validator: NaturgyPaymentsRequestValidator,
  },
  // keys are part of the emu common structure for payments
  // values are part of the microservice response
  response: {
    msResponse: null,
    paymentId: 'paymentId',
    transactionId: 'couponNumber',
    message: 'message',
    code: 'code',
  },
};

exports.utility = {
  30657864117: {
    balances,
    payments,
  },
};
