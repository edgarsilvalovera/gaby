import { EdenorPaymentsRequestValidator } from '../../entities/';

// keys are part of the emu common structure for balances
// values are part of the microservice response (microservice name is "beyond")
const balances = {
  msResponse: 'balances',
  paymentDocument: 'cuentaId',
  customerName: 'titular',
  customerAddress: 'direccion',
  balances: 'saldos',
  balancesDetail: {
    amount: 'monto',
    isPayable: 'esPagable',
    concept: 'concepto',
    message: 'mensaje',
    dueDate: null,
  },
};

const payments = {
  // keys are part of the cached microservice response
  // values are part of the request to the microservice
  // paymentMethod (in request) come from the payment request
  request: {
    cuentaId: 'edenorAccount',
    monto: 'amount',
    concepto: 'concept',
    paymentMethod: 'paymentType',
  },
  entity: {
    Validator: EdenorPaymentsRequestValidator,
  },
  // keys are part of the emu common structure for payments
  // values are part of the microservice response
  response: {
    msResponse: null,
    paymentId: 'paymentId',
    transactionId: 'idTransaccion',
    message: 'message',
    code: 'code',
  },
};

exports.utility = {
  30655116202: {
    balances,
    payments,
  },
};
