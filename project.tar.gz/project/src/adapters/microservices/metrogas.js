import { MetrogasPaymentsRequestValidator } from '../../entities/';

// keys are part of the emu common structure for balances
// values are part of the microservice response
const balances = {
  msResponse: null,
  paymentDocument: 'paymentFormId',
  customerName: null,
  customerAddress: null,
  balances: 'balances',
  balancesDetail: {
    amount: 'paymentAmount',
    isPayable: null,
    concept: null,
    message: null,
    dueDate: 'dueDate',
  },
};

const payments = {
  // keys are part of the cached microservice response
  // values are part of the request to the microservice
  // paymentMethod (in request) come from the payment request
  request: {
    invoiceReferenceId: 'invoiceReferenceId',
    payerContractAccountId: 'payerContractAccountId',
    paymentAmount: 'paymentAmount',
    paymentFormId: 'paymentFormId',
    documents: 'documents',
    paymentMethod: 'paymentType',
  },
  entity: {
    Validator: MetrogasPaymentsRequestValidator,
  },
  // keys are part of the emu common structure for payments
  // values are part of the microservice response
  response: {
    msResponse: null,
    paymentId: 'paymentId',
    transactionId: 'idTransaccion',
    message: null,
    code: null,
  },
};

exports.utility = {
  30657863676: {
    balances,
    payments,
  },
};
