import { GasnorPaymentsRequestValidator } from '../../entities/';

// keys are part of the emu common structure for balances
// values are part of the microservice response
const balances = {
  msResponse: null,
  paymentDocument: 'paymentDocument',
  customerName: null,
  customerAddress: null,
  balances: 'balances',
  balancesDetail: {
    amount: 'amount',
    isPayable: null,
    documentType: 'documentType',
    branch: 'branch',
    concept: null,
    message: null,
    dueDate: 'dueDate',
  },
};

const payments = {
  // keys are part of the cached microservice response
  // values are part of the request to the microservice
  // paymentMethod (in request) come from the payment request
  request: {
    paymentDocument: 'paymentDocument',
    amount: 'amount',
    paymentMethod: 'paymentMethod',
    documentType: 'documentType',
    branch: 'branch',
    dueDate: 'dueDate',
  },
  entity: {
    Validator: GasnorPaymentsRequestValidator,
  },
  // keys are part of the emu common structure for payments
  // values are part of the microservice response
  response: {
    msResponse: 'payment',
    paymentId: 'paymentId',
    transactionId: 'paymentTransactionId',
    message: null,
    code: null,
  },
};

exports.utility = {
  30657865725: {
    balances,
    payments,
  },
};
