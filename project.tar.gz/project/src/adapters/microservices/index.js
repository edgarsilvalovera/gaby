import fs from 'fs';

const files = fs.readdirSync(__dirname);

const utilities = files
  .filter((filename) => filename !== 'index.js')
  .reduce((previousContent, filename) => {
    const { utility } = require(`./${filename}`);
    return { ...previousContent, ...utility };
  }, {});

export default utilities;
