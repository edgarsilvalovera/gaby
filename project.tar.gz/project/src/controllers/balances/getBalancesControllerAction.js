import { ControllerResponse } from '../../contracts/';
import { ORIGIN } from '../../constants/balanceOrigin';

function getBalancesControllerAction({
  getUtility,
  getBalances,
  parseBalances,
  saveBalances,
  getTapiBalance,
}) {
  async function executer(requestParams) {
    const {
      urlParams: { cuit },
    } = requestParams;

    // look for a utility in the database
    const utility = await getUtility(cuit);

    const { tapiUp = false } = utility;

    const getBalancesExecute = tapiUp ? getTapiBalance : getBalances;

    // retrieve balances from the utility
    const { request, response, status } = await getBalancesExecute({
      requestParams,
      utility,
    });

    // return a common structure of balances and the original response
    // with a correlation to this new structure (balanceId property)
    const { parsedResponse, originalResponse } = parseBalances({
      data: response,
      cuit,
      tapiBalance: tapiUp,
    });

    // save original response (with correlation) in cache
    await saveBalances({
      searchId: parsedResponse.balancesInfo.searchId,
      request,
      response: originalResponse,
      origin: tapiUp ? ORIGIN.TAPI : ORIGIN.UTILITIES,
    });
    return new ControllerResponse(parsedResponse, status);
  }
  return executer;
}

export default getBalancesControllerAction;
