describe('Get Balances Controller Instance', () => {
  it('Get Balances Controller Instance - UtilityNotFound', async () => {
    // const requestParams = makeFakeBalanceWithUtilityNotFound;
    // let method = () => getBalancesControllerInstance(requestParams);
    // let utilityNotFoundError = 'UT04040';
    // await expectCodeThrowsAsync(method, utilityNotFoundError);
  });
});
