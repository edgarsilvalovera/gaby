import { fakeRequestParams } from '../../../../__test__/makeFakeRequestParamsBalance';
import { ControllerResponse } from '../../../contracts';
import getBalanceController from '..';
import { nockTapiBalance } from '../../../../__test__/mocks/gateways/tapi/nocks/nocks';
import { getFakeResponseFindByCuitUtilityByCuit } from '../../../../__test__/mocks/models/utility/makeFakeResponseFindByCuitUtility';
import { LITORAL_GAS_CUIT } from '../../../../__test__/utilitiesCuitTest';
import { cleanDb } from '../../../../__test__/cleanDb';
import UtilityModel from '../../../models/UtilityModel';
import nock from 'nock';

describe('Get Balances ( TAPI ) Controller Action', () => {
  afterAll(async () => {
    await cleanDb();
    nock.cleanAll();
    jest.clearAllMocks();
  });

  it('should get tapi balance ok', async () => {
    await createUtility();

    nockTapiBalance();

    const response = await getBalanceController(fakeRequestParams);

    expect(response).toBeInstanceOf(ControllerResponse);
  });
});

const createUtility = async (cuit = LITORAL_GAS_CUIT) => {
  const fakeUtility = getFakeResponseFindByCuitUtilityByCuit(cuit);

  fakeUtility.tapiUp = true;

  const utility = new UtilityModel();

  await utility.create(fakeUtility);
};
