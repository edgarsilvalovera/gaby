import getBalancesControllerAction from '../getBalancesControllerAction';
import { fakeRequestParams } from '../../../../__test__/makeFakeRequestParamsBalance';
import { ControllerResponse } from '../../../contracts';
import { parametersGetBalancesControllerAction } from '../../../../__test__/makeParameters/balances/makeParametersGetBalancesControllerAction';

describe('Get Balances Controller Action', () => {
  it('Method getBalancesControllerAction() should return a function', async () => {
    let executer = getBalancesControllerAction(parametersGetBalancesControllerAction);
    expect(typeof executer).toBe('function');
  });

  it('Method getBalancesControllerAction() should return a ControllerResponse', async () => {
    let executer = getBalancesControllerAction(parametersGetBalancesControllerAction);
    let response = await executer(fakeRequestParams);

    expect(response).toBeInstanceOf(ControllerResponse);
  });
});
