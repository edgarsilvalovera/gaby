import getBalancesControllerAction from './getBalancesControllerAction';
import parseBalances from '../../adapters/parseBalances';
import { getBalancesUsecaseInstance, getTapiBalanceInstance } from '../../usecases/balances/';
import { saveBalancesUsecaseInstance } from '../../usecases/cache/';
import { getUtilityUsecaseInstance } from '../../usecases/utilities/';

const getBalancesControllerInstance = getBalancesControllerAction({
  getUtility: getUtilityUsecaseInstance,
  getBalances: getBalancesUsecaseInstance,
  parseBalances,
  getTapiBalance: getTapiBalanceInstance,
  saveBalances: saveBalancesUsecaseInstance,
});

export default getBalancesControllerInstance;
