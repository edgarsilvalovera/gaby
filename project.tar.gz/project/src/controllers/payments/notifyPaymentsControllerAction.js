import { ControllerResponse } from '../../contracts/';
import { ORIGIN } from '../../constants/balanceOrigin';
import { CachedBalanceNotFound } from '../../exceptions';

function notifyPaymentsControllerAction({
  getCachedBalances,
  getBalanceToPay,
  notifyPayments,
  processTapiPayment,
  parseResponsePayments,
  sendSqsMessage,
  logError,
}) {
  async function executer(requestParams) {
    requestParams.body = JSON.parse(requestParams.body.body);

    // balanceId is not received in the interoperability (it's just one balance)
    // mainTx is only received in the interoperability
    const {
      body: { searchId, balanceId = null, mainTx = null },
    } = requestParams;

    const cachedData = await getCachedBalances(searchId);

    if (!cachedData) throw new CachedBalanceNotFound();

    const { origin = '' } = cachedData;

    const isTapiOrigin = origin === ORIGIN.TAPI;

    //tapi response is normalized so if its from tapi origin return cachedData without transformations
    const balanceToPay = isTapiOrigin
      ? cachedData
      : await getBalanceToPay(searchId, balanceId, cachedData);

    let response;
    let status;

    // wrapper to log errors when sqs messages could not be sent
    const logSQSError = (sqsError, sqsStatus) => {
      logError({
        message: `could not send the ${sqsStatus} message to sqs`,
        utility: cachedData.response.utility,
        mainTx,
        metadata: { ...sqsError },
        filename: __filename,
      });
    };

    try {
      const notifyPaymentExecuter = isTapiOrigin ? processTapiPayment : notifyPayments;

      const { response: paymentResponse, status: paymentStatus } = await notifyPaymentExecuter({
        requestParams,
        balanceToPay,
      });

      response = paymentResponse;
      status = paymentStatus;
    } catch (error) {
      await sendSqsMessage({ params: { data: { qrIdTrx: mainTx, status: 'error' } } }).catch(
        (sqsError) => {
          logSQSError(sqsError, 'error');
        },
      );

      throw error;
    }

    const parsedResponse = parseResponsePayments({
      data: response,
      cuit: balanceToPay.request.params.cuit,
      tapiOrigin: isTapiOrigin,
    });

    await sendSqsMessage({ params: { data: { qrIdTrx: mainTx, status: 'success' } } }).catch(
      (sqsError) => {
        logSQSError(sqsError, 'success');
      },
    );

    return new ControllerResponse(parsedResponse, status);
  }

  return executer;
}

export default notifyPaymentsControllerAction;
