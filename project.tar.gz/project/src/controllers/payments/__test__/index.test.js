import { makeFakePaymentRequest } from '../../../../__test__/makeFakeRequestParamsPayment';
import { PaymentsResponse } from '../../../contracts';
import {
  nockTapiPayment,
  nockTapiPaymentError,
} from '../../../../__test__/mocks/gateways/tapi/nocks/nocks';

import notifyPaymentsController from '..';
import balanceModel from '../../../../src/models/BalancesCacheModel';
import { getFakeResponseReadRedisByCuit } from '../../../../__test__/mocks/models/redis/makeFakeResponseReadRedis';
import * as uuid from 'uuid';
import { LITORAL_GAS_CUIT } from '../../../../__test__/utilitiesCuitTest';
import { CachedBalanceNotFound, UtilityInternalServerError } from '../../../exceptions';
import { expectErrorBeInstanceOfAsync } from '../../../../__test__/expectThrowsAsync';

describe('Notify payment ( TAPI ) Controller Action', () => {
  it('should process payment sucessfully', async () => {
    nockTapiPayment();

    const searchId = await cacheBalance();

    const request = makeFakePaymentRequest({ searchId });

    const { status, response } = await notifyPaymentsController(request);

    expect(status).toBe(200);
    expect(response).toBeInstanceOf(PaymentsResponse);
  });

  it('should throw error if cached balance is not found', async () => {
    const request = makeFakePaymentRequest({ searchId: 'fake' });

    await expectErrorBeInstanceOfAsync(
      () => notifyPaymentsController(request),
      CachedBalanceNotFound,
    );
  });

  it('should throw error if tapi reply with error', async () => {
    const searchId = await cacheBalance();

    const request = makeFakePaymentRequest({ searchId });

    nockTapiPaymentError();

    await expectErrorBeInstanceOfAsync(
      () => notifyPaymentsController(request),
      UtilityInternalServerError,
    );
  });
});

const cacheBalance = async () => {
  const searchId = uuid.v4();
  //insert balance response with tapi origin
  const response = getFakeResponseReadRedisByCuit(LITORAL_GAS_CUIT, true);

  await new balanceModel().save(searchId, JSON.parse(response));

  return searchId;
};
