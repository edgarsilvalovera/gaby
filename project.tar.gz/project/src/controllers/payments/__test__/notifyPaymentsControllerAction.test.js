import { fakeRequestParamsPayment } from '../../../../__test__/makeFakeRequestParamsPayment';
import { parametersNotifyPaymentsControllerAction } from '../../../../__test__/makeParameters/makeParametersNotifyPaymentsControllerAction';
import { FAKE_BALANCE_ID } from '../../../../__test__/utilFakeId';
import { ControllerResponse } from '../../../contracts';
import notifyPaymentsControllerAction from '../notifyPaymentsControllerAction';

fakeRequestParamsPayment.body.body = JSON.parse(fakeRequestParamsPayment.body.body);

describe('Get Balances Controller Action', () => {
  it('Method notifyPaymentsControllerAction() should return a function', async () => {
    let executer = notifyPaymentsControllerAction(parametersNotifyPaymentsControllerAction);
    expect(typeof executer).toBe('function');
  });

  it('Method getBalancesControllerAction() should return a ControllerResponse', async () => {
    //to don't get the exception CachedBalanceNotFound
    fakeRequestParamsPayment.body.body.balanceId = FAKE_BALANCE_ID;
    fakeRequestParamsPayment.body.body = JSON.stringify(fakeRequestParamsPayment.body.body);

    let executer = notifyPaymentsControllerAction(parametersNotifyPaymentsControllerAction);
    let response = await executer(fakeRequestParamsPayment);

    expect(response).toBeInstanceOf(ControllerResponse);
  });
});
