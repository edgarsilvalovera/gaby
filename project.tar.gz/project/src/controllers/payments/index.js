import notifyPaymentsControllerAction from './notifyPaymentsControllerAction';
import { parseResponsePayments } from '../../adapters/parsePayments';
import { logError } from '../../logger/';
import { getBalancesUsecaseInstance } from '../../usecases/cache/';
import {
  getBalanceToPayUsecaseInstance,
  notifyPaymentsUsecaseInstance,
  processTapiPaymenUseCaseInstance,
} from '../../usecases/payments/';
import { sendSqsMessage } from '../../usecases/sqs/';

const notifyPaymentsControllerInstance = notifyPaymentsControllerAction({
  getCachedBalances: getBalancesUsecaseInstance,
  getBalanceToPay: getBalanceToPayUsecaseInstance,
  notifyPayments: notifyPaymentsUsecaseInstance,
  processTapiPayment: processTapiPaymenUseCaseInstance,
  parseResponsePayments,
  sendSqsMessage,
  logError,
});

export default notifyPaymentsControllerInstance;
