import { INTERNAL_SERVER_ERROR } from 'http-status';
import EMU from '../../constants/emu';
import { ErrorResponse } from '../../contracts/';
import { keysToSnake } from '../../helpers/keyParsers';
import { logRequest, logResponse, logError } from '../../logger/';

function routeHandler(functionController) {
  const {
    qrTypes: { iep: iepQR },
    headers: { mainTx: mainTxHeader, accountId: accountIdHeader },
    services: {
      payments: { endpoint: paymentsEndpoint },
    },
  } = EMU;

  async function handle(req, res) {
    const startTime = process.hrtime();
    const mainTx = req.get(mainTxHeader) || null;
    const accountId = req.get(accountIdHeader) || null;

    const logData = { mainTx, accountId, startTime, filename: __filename };

    const { params: urlParams = {}, query: queryParams = {}, body = {} } = req;

    logRequest({
      message: `request from ${getSourceRequest(req)}`,
      ...logData,
      req,
    });

    try {
      const { response, status } = await functionController({
        headers: {
          [mainTxHeader]: mainTx,
          [accountIdHeader]: accountId,
        },
        urlParams,
        queryParams,
        body,
        globalStartTime: startTime,
      });

      logResponse({
        message: 'parsed response received from the utility',
        ...logData,
        status,
        metadata: response,
      });

      res.status(status).json(keysToSnake({ ...response }));
    } catch (error) {
      const {
        code = 'UT00001',
        message,
        constructor: { name },
        status = INTERNAL_SERVER_ERROR,
      } = error;

      logError({
        message: `${name} Exception => ${message}`,
        ...logData,
        status,
        metadata: { ...error },
      });

      res.status(status).json(new ErrorResponse(code, message));
    }
  }

  function getSourceRequest(req) {
    const { query: { qrType = null } = {}, body: { body = null } = {}, originalUrl } = req;
    // any request from the app
    let sourceRequest = 'TAP';

    if (qrType === iepQR) {
      // request for balances from iep
      sourceRequest = 'IEP';
    } else if (originalUrl === paymentsEndpoint && body) {
      // request for payments from qr-confirm-debit (aws sqs)
      const parsedBody = JSON.parse(body);
      parsedBody.pspId && (sourceRequest = 'SQS');
    }

    return sourceRequest;
  }

  return handle;
}

export default routeHandler;
