import { keysToCamel } from '../../../helpers/keyParsers';

function keyParser(req, _res, next) {
  const { body = {}, params = {}, query = {} } = req;

  req.body = keysToCamel(body);
  req.params = keysToCamel(params);
  req.query = keysToCamel(query);

  next();
}

export default keyParser;
