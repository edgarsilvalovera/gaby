import { BAD_REQUEST, UNAUTHORIZED, NOT_FOUND, INTERNAL_SERVER_ERROR } from 'http-status';
import { ErrorResponse } from '../../../contracts/';
import { logError } from '../../../logger/';
import {
  OASpecBadRequest,
  OASpecUnauthorized,
  OASpecNotFound,
  OASpecBadResponse,
} from '../../../exceptions/';

// eslint-disable-next-line no-unused-vars
function errorHandler(err, req, res, _next) {
  // come from security handlers (forbidden by open api specification)
  let oaspecError = req.oaspecValidator || {};

  // other errors by open api specification
  if (err.status && err.errors) {
    if (err.status === BAD_REQUEST) {
      oaspecError = new OASpecBadRequest();
    } else if (err.status === UNAUTHORIZED) {
      oaspecError = new OASpecUnauthorized();
    } else if (err.status === NOT_FOUND) {
      oaspecError = new OASpecNotFound();
    } else if (err.status === INTERNAL_SERVER_ERROR && err.message.match(/^\.response/)) {
      oaspecError = new OASpecBadResponse();
    }
  }

  // error values by open api specification
  const {
    code: codeOASpecValidator = null,
    message: messageOASpecValidator = null,
    constructor: { name: nameOASpecValidator },
  } = oaspecError;

  // error values by default
  const {
    code: codeErr = 'UT00000',
    message: messageErr,
    constructor: { name: nameErr },
    status = INTERNAL_SERVER_ERROR,
  } = err;

  const code = codeOASpecValidator || codeErr;
  const message = messageOASpecValidator || messageErr;
  const name = nameOASpecValidator !== 'Object' ? nameOASpecValidator : nameErr;

  logError({
    message: `${name} Exception => ${message}`,
    status,
    metadata: { ...err },
    filename: __filename,
  });

  res.status(status).json(new ErrorResponse(code, message));
}

export default errorHandler;
