import express from 'express';
import handle from '../routeHandler';
import getBalancesController from '../../../controllers/balances/';

const router = express.Router();

router.get('/:cuit/:document', handle(getBalancesController));

export default router;
