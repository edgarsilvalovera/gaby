import express from 'express';
import swaggerUi from 'swagger-ui-express';

const router = express.Router();

router.use('/spec', express.static('.openapi/api.json'));

router.use('/docs', swaggerUi.serve);
router.get('/docs', swaggerUi.setup(require('../../../../.openapi/api.json')));

export default router;
