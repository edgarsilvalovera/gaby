import express from 'express';
import handle from '../routeHandler';
import notifyPaymentsController from '../../../controllers/payments/';

const router = express.Router();

router.post('/', handle(notifyPaymentsController));

export default router;
