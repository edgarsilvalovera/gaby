import * as uuid from 'uuid';
import EMU from '../../../constants/emu';
import { OASpecForbidden } from '../../../exceptions/';

const {
  headers: { mainTx: mainTxHeader, accountId: accountIdHeader },
} = EMU;

// eslint-disable-next-line no-unused-vars
function mainTx(req, _scopes, _schema) {
  if (!uuid.validate(req.get(mainTxHeader))) {
    req.oaspecValidator = new OASpecForbidden(mainTxHeader);
    throw req.oaspecValidator;
  }

  return true;
}

// eslint-disable-next-line no-unused-vars
function accountId(req, _scopes, _schema) {
  if (!uuid.validate(req.get(accountIdHeader))) {
    req.oaspecValidator = new OASpecForbidden(accountIdHeader);
    throw req.oaspecValidator;
  }

  return true;
}

export { mainTx, accountId };
