import { nockTapiPayment } from '../../../../__test__/mocks/gateways/tapi/nocks/nocks';
import supertest from 'supertest';
import { config } from 'config';
import { cacheBalance } from '../../../../__test__/makeCacheBalance';
import { v4 } from 'uuid';

const request = supertest(`http://127.0.0.1:${config.publicPort}`);

describe('Notify payment ( TAPI ) Controller Action', () => {
  beforeAll(async () => {
    require('../server');
  });

  it('should process payment sucessfully', async () => {
    const { mockResponse } = nockTapiPayment();

    const expectedResponse = {
      main_tx: mockResponse.operation.mainTx,
      tx: mockResponse.operation.tx,
      payments_info: {
        message: null,
        code: null,
        transaction_id: mockResponse.operation.operationId,
        payment_id: mockResponse.operation.transactionId,
      },
    };

    const searchId = await cacheBalance();

    const bodyJson = {
      searchId,
      mainTx: v4(),
      totalAmount: 10,
      pspId: 1,
    };

    const { status, body } = await executeRequest({
      endpoint: '/payments',
      params: { body: JSON.stringify(bodyJson) },
    });

    expect(status).toBe(200);
    expect(body).toEqual(expectedResponse);
  });

  it('should throw error if balance is not found', async () => {
    const bodyJson = {
      searchId: 'fake',
      mainTx: v4(),
      totalAmount: 10,
      pspId: 1,
    };

    const { status, body } = await executeRequest({
      endpoint: '/payments',
      params: { body: JSON.stringify(bodyJson) },
    });

    expect(status).toBe(404);
    expect(body.code).toBe('UT24042');
  });

  async function executeRequest({ endpoint, params }) {
    return request
      .post(endpoint)
      .send(params)
      .set('x-account-id', v4())
      .set('x-main-tx', v4())
      .set('Content-Type', 'application/json');
  }
});
