import { nockTapiBalance } from '../../../../__test__/mocks/gateways/tapi/nocks/nocks';
import supertest from 'supertest';
import { config } from 'config';
import { v4 } from 'uuid';
import { fakeRequestParams } from '../../../../__test__/makeFakeRequestParamsBalance';

const request = supertest(`http://127.0.0.1:${config.publicPort}`);

describe('Balance ( TAPI ) Controller Action', () => {
  beforeAll(async () => {
    require('../server');
  });

  it('testing with pspID', async () => {
    nockTapiBalance();

    const {
      urlParams: { cuit, document },
      queryParams,
    } = fakeRequestParams;

    const { status } = await executeRequest({
      endpoint: `/balances/${cuit}/${document}`,
      params: { queryParams },
    });
    expect(status).toBe(200);
  });

  it('testing without pspId', async () => {
    nockTapiBalance();

    const {
      urlParams: { cuit, document },
      queryParams: { qrType },
    } = fakeRequestParams;

    const { status } = await executeRequest({
      endpoint: `/balances/${cuit}/${document}`,
      params: { qrType },
    });
    expect(status).toBe(200);
  });

  async function executeRequest({ endpoint, params }) {
    const { queryParams } = params;
    return request
      .get(endpoint)
      .query(queryParams)
      .set('x-account-id', v4())
      .set('x-main-tx', v4())
      .set('Content-Type', 'application/json');
  }
});
