import { config } from 'config';
import express from 'express';
import * as OpenApiValidator from 'express-openapi-validator';
import errorHandler from './middlewares/errorHandler';
import keyParser from './middlewares/keyParser';
import * as securityHandlers from './openapiValidator/securityHandlers';
import apiRouter from './routes/api';
import balancesRouter from './routes/balances';
import healthRouter from './routes/healths';
import paymentRouter from './routes/payments';
import { name, version, description } from '../../../package.json';

const { publicPort } = config;

const apiSpecPath = '.openapi/api.json';

const app = express();

app.use(express.urlencoded({ extended: false }));
app.use(express.json());
app.use(keyParser);

//validate requests/responses by using open api specification
app.use(
  OpenApiValidator.middleware({
    apiSpec: apiSpecPath,
    validateResponses: true,
    ignorePaths: /^\/api\/docs.*/,
    validateSecurity: {
      handlers: securityHandlers,
    },
  }),
);

app.use('/', healthRouter);
app.use('/api', apiRouter);
app.use('/balances', balancesRouter);
app.use('/payments', paymentRouter);

app.use(errorHandler);

const server = app.listen(publicPort, () => {
  console.log(`${name} v${version} listening on port ${publicPort} on ${new Date()}`);
  console.log(JSON.stringify(config));
});

const start = () => {
  console.log(description);
  return app;
};

const close = () => {
  server.close();
};

export { start, close };
