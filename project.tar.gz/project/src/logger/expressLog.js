import log4js from 'log4js';
import moment from 'moment';

// check if tests are running
const isTesting = process.env.NODE_ENV === 'test';
// disable logs if tests are running
const defaultLevel = !isTesting ? 'info' : 'off';

const INFO = 'info';
const ERROR = 'error';

function logger() {
  const $this = config();

  function config() {
    log4js.addLayout('json', () => (logEvent) => {
      const {
        data: [log],
        level,
      } = logEvent;

      const logInfo =
        typeof log === 'object'
          ? JSON.stringify({
              time: moment().format('YYYY-MM-DD HH:mm:ss'),
              ...log,
            })
          : `└───>> ${log}`;

      return `${level.levelStr.toLowerCase()}: ${logInfo}`;
    });

    log4js.configure({
      appenders: {
        out: { type: 'stdout', layout: { type: 'json', separator: ',' } },
      },
      categories: {
        default: { appenders: ['out'], level: defaultLevel },
      },
    });

    return log4js.getLogger();
  }

  function message(level, data) {
    $this[level](data);
  }

  function info(data = {}) {
    const { level = INFO, ...restData } = data;
    message(level, restData);
  }

  function error(data = {}) {
    const { level = ERROR, ...restData } = data;
    message(level, restData);
  }

  return { info, error };
}

export default logger();
