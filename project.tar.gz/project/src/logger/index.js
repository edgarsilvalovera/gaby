import logger from './expressLog';

function logInfo({
  message = null,
  utility = null,
  mainTx = null,
  accountId = null,
  metadata = {},
  startTime = null,
  filename = null,
}) {
  logger.info({
    message,
    utility,
    main_tx: mainTx,
    external_ref: accountId,
    metadata,
    duration: getElapsedTime(startTime),
    filename,
  });
}

function logRequest(data) {
  const { metadata, req } = data;
  const { body = {}, params = {}, query = {}, method, originalUrl: url } = req;

  const allMetadata = {
    path: url,
    method,
    ...body,
    ...query,
    ...params,
    ...metadata,
  };

  logInfo({ ...data, metadata: allMetadata });
}

function logResponse(data) {
  const { status, metadata } = data;

  logInfo({ ...data, metadata: { status, ...metadata } });
}

function logError({
  message = null,
  utility = null,
  mainTx = null,
  accountId = null,
  status = null,
  metadata = {},
  startTime = null,
  filename = null,
}) {
  logger.error({
    message,
    utility,
    main_tx: mainTx,
    external_ref: accountId,
    metadata: { status, ...metadata },
    duration: getElapsedTime(startTime),
    filename,
  });
}

function getElapsedTime(startTime) {
  if (!startTime) {
    return '--';
  }

  const [secs, nanos] = process.hrtime(startTime);
  return `${(secs * 1000 + nanos / 1000000).toFixed(6)} ms`;
}

export { logInfo, logRequest, logResponse, logError };
