import { start } from './deliveries/express/server';

start();
