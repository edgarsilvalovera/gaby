import moment from 'moment';
import * as uuid from 'uuid';
import { InvalidEntity } from '../exceptions/';

class BaseEntity {
  constructor(entity = null) {
    this.entity = entity || this.constructor.name;
    this.dataTypes = {
      string: 'String',
      number: 'Number',
      integer: 'Integer',
      amount: 'Amount',
      boolean: 'Boolean',
      datetime: 'Datetime',
      date: 'Date',
      url: 'URL',
      endpoint: 'Endpoint',
      uuid: 'UUID',
      object: 'Object',
      array: 'Array',
    };
  }

  validateString(field, value, required = true, pattern = null, type = this.dataTypes.string) {
    if (!required && !value && value !== '') {
      return null;
    }

    if (required && !value) {
      this.throwExceptionByRequired(field);
    }

    if (typeof value !== 'string') {
      this.throwExceptionByInvalidValue(field, value, type);
    }

    if (pattern && !value.match(pattern)) {
      this.throwExceptionByInvalidValue(field, value);
    }

    return value;
  }

  validateNumber(field, value, required = true, zero = false) {
    if (!required && !value && value !== 0) {
      return null;
    }

    if (!zero && value === 0) {
      this.throwExceptionByZero(field);
    }

    if (required && !zero && !value) {
      this.throwExceptionByRequired(field);
    }

    if (Number.isNaN(value)) {
      this.throwExceptionByInvalidValue(field, value, this.dataTypes.number);
    }

    return +value;
  }

  validateInteger(field, value, required = true, zero = false) {
    const validated = this.validateNumber(field, value, required, zero);

    if (validated === null) {
      return null;
    }

    if (validated !== null && !Number.isInteger(value)) {
      this.throwExceptionByInvalidValue(field, value, this.dataTypes.integer);
    }

    return +value;
  }

  validateAmount(field, value, required = true, zero = false, decimals = 2) {
    const validated = this.validateNumber(field, value, required, zero);

    return validated !== null ? +validated.toFixed(decimals) : null;
  }

  validateBoolean(field, value, required = true) {
    if (!required && !value && value !== false) {
      return null;
    }

    if (required && !value && value !== false) {
      this.throwExceptionByRequired(field);
    }

    if (typeof value !== 'boolean') {
      this.throwExceptionByInvalidValue(field, value, this.dataTypes.boolean);
    }

    return value;
  }

  validateDatetime(field, value, required = true, type = this.dataTypes.datetime) {
    if (!required && !value) {
      return null;
    }

    if (required && !value) {
      this.throwExceptionByRequired(field);
    }

    const datetime = value.replace(/[/-:]/g, '');

    if (
      !moment(value).isValid() ||
      !moment(datetime, ['YYYYMMDD HHmmss', 'DDMMYYYY HHmmss']).isValid()
    ) {
      this.throwExceptionByInvalidValue(field, value, type);
    }

    return value;
  }

  validateDate(field, value, required = true) {
    return this.validateDatetime(field, `${value} 000000`, required, this.dataTypes.date);
  }

  validateURL(field, value, required = true) {
    return this.validateString(
      field,
      value,
      required,
      '^(https?:)((\\/\\/\\/?)([\\w]*(?::[\\w]*)?@)?([\\d\\w\\.-]+)(?::(\\d+))?)?([\\/\\\\\\w\\.()-]*)?(?:([?][^#]*)?(#.*)?)*$',
      this.dataTypes.url,
    );
  }

  validateEndpoint(field, value, required = true) {
    return this.validateString(
      field,
      value,
      required,
      '^\\/(?:\\w+\\/?)+#?\\w*[?]?(?:&?\\w+[=\\w+])*$',
      this.dataTypes.endpoint,
    );
  }

  validateUUID(field, value, required = true) {
    const validated = this.validateString(field, value, required, null, this.dataTypes.uuid);

    if (validated === null) {
      return null;
    }

    if (validated !== null && !uuid.validate(value)) {
      this.throwExceptionByInvalidValue(field, value);
    }

    return value;
  }

  validateObject(field, value, required = true, properties = {}) {
    if (!required && !value) {
      return null;
    }

    if (required && (!value || !Object.keys(value))) {
      this.throwExceptionByRequired(field);
    }

    if (typeof value !== 'object') {
      this.throwExceptionByInvalidValue(field, value, this.dataTypes.object);
    }

    const result = {};

    for (const key in properties) {
      if (Object.hasOwnProperty.call(properties, key)) {
        const {
          type: propertyDataType,
          required: propertyRequired = true,
          pattern: propertyPattern = null,
          zero: propertyZero = false,
          decimals: propertyDecimals = 2,
        } = properties[key];

        const property = `${field}::${key}`;
        let validatedValue = value[key];

        switch (propertyDataType) {
          case this.dataTypes.string:
            validatedValue = this.validateString(
              property,
              value[key],
              propertyRequired,
              propertyPattern,
            );
            break;
          case this.dataTypes.number:
          case this.dataTypes.integer:
            validatedValue = this[`validate${propertyDataType}`](
              property,
              value[key],
              propertyRequired,
              propertyZero,
            );
            break;
          case this.dataTypes.amount:
            validatedValue = this.validateAmount(
              property,
              value[key],
              propertyRequired,
              propertyZero,
              propertyDecimals,
            );
            break;
          case this.dataTypes.boolean:
          case this.dataTypes.datetime:
          case this.dataTypes.date:
          case this.dataTypes.url:
          case this.dataTypes.endpoint:
          case this.dataTypes.uuid:
          case this.dataTypes.object:
            validatedValue = this[`validate${propertyDataType}`](
              property,
              value[key],
              propertyRequired,
            );
        }

        result[key] = validatedValue;
      }
    }

    return Object.keys(result).length ? result : value;
  }

  validateArray(field, value, required = true) {
    if (!required && !value) {
      return null;
    }

    if (required && (!value || !value.length)) {
      this.throwExceptionByRequired(field);
    }

    if (!Array.isArray(value)) {
      this.throwExceptionByInvalidValue(field, value, this.dataTypes.array);
    }

    return value;
  }

  throwExceptionByRequired(field) {
    this.throwException(field, 'is required');
  }

  throwExceptionByInvalidValue(field, value, type = 'value') {
    this.throwException(field, `received an invalid ${type} => ${value}`);
  }

  throwExceptionByZero(field) {
    this.throwException(field, 'cannot be zero');
  }

  throwException(field, reason) {
    const message = `${this.entity}::${field} ${reason}`;
    throw new InvalidEntity(message);
  }
}

export { BaseEntity };
