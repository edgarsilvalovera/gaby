import { PaymentsRequestValidator } from './PaymentsRequestValidator';

class AysaPaymentsRequestValidator extends PaymentsRequestValidator {
  constructor({ body = null, ...restParameters }) {
    super('AysaPaymentsRequestValidator', restParameters);
    this._body = body;
    this._totalAmount = body.totalAmount;
  }

  set _body(value) {
    const properties = {
      paymentDocument: {
        type: this.dataTypes.string,
        pattern: '^[A-Za-z0-9 ]+$',
      },
      amount: {
        type: this.dataTypes.amount,
      },
      paymentReference: {
        type: this.dataTypes.string,
      },
      dueDate: {
        type: this.dataTypes.string,
      },
      cuit: {
        type: this.dataTypes.string,
        pattern: '\\d{11}',
      },
      documentType: {
        type: this.dataTypes.string,
        pattern: '\\d{1}',
      },
      secondDueDateDisplacement: {
        type: this.dataTypes.number,
        zero: true,
      },
      companyCode: {
        type: this.dataTypes.string,
        pattern: '\\d{3}',
      },
      entityCode: {
        type: this.dataTypes.string,
        pattern: '\\d{3}',
      },
      recharge: {
        type: this.dataTypes.amount,
        zero: true,
      },
    };

    this.body = this.validateObject('body', value, true, properties);
  }

  set _totalAmount(value) {
    this.compareAmounts('amount', value, this.body.amount);
  }
}

export { AysaPaymentsRequestValidator };
