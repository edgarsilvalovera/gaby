import { BaseEntity } from './BaseEntity';
import EMU from '../constants/emu';

const {
  qrTypes: { iep },
  headers: { mainTx, accountId },
} = EMU;

class PaymentsRequestValidator extends BaseEntity {
  constructor(entity, { utility = null, baseURL = null, headers = null, queryParams = null }) {
    super(entity);

    this._queryParams = queryParams;

    this.isInteroperable = this.queryParams.qrType === iep;

    this._headers = headers;

    this._baseURL = baseURL;

    this._utility = utility;

    this.paymentTypePattern = '^(?:tap|debit|credit)$';
  }

  set _queryParams(value) {
    const properties = {
      qrType: {
        type: this.dataTypes.string,
        pattern: '^(?:iep|service)$',
      },
      cuit: {
        type: this.dataTypes.string,
        pattern: '^\\d{11}$',
      },
      pspId: {
        type: this.dataTypes.integer,
        zero: true,
      },
    };

    this.queryParams = this.validateObject('queryParams', value, true, properties);
  }

  set _headers(value) {
    const properties = {
      [mainTx]: {
        type: this.dataTypes.uuid,
      },
      [accountId]: {
        type: this.dataTypes.uuid,
        required: !this.isInteroperable,
      },
    };

    this.headers = this.validateObject('headers', value, true, properties);
  }

  set _baseURL(value) {
    this.baseURL = this.validateURL('baseURL', value, true);
  }

  set _utility(value) {
    this.utility = this.validateString('utility', value, true, '^[A-Za-z][\\w|\\-|\\.| ]+$');
  }

  compareAmounts(field, request, cache) {
    const amountInRequest = this.validateAmount('totalAmount', request);
    const amountInCache = this.validateAmount('cachedAmount', cache);

    if (amountInRequest !== amountInCache) {
      this.throwException(field, 'differs between request and cache');
    }
  }
}

export { PaymentsRequestValidator };
