import { PaymentsRequestValidator } from './PaymentsRequestValidator';

class EdenorPaymentsRequestValidator extends PaymentsRequestValidator {
  constructor({ body = null, ...restParameters }) {
    super('EdenorPaymentsRequestValidator', restParameters);
    this._body = body;
    this._totalAmount = body.totalAmount;
  }

  set _body(value) {
    const properties = {
      edenorAccount: {
        type: this.dataTypes.string,
        pattern: '^\\d{10}$',
      },
      amount: {
        type: this.dataTypes.amount,
      },
      concept: {
        type: this.dataTypes.string,
        pattern: '^(?:saldo_total|saldo_vencido|ultima_factura|plan_de_pago|saldo_parcial)$',
      },
      paymentType: {
        type: this.dataTypes.string,
        pattern: this.paymentTypePattern,
      },
    };

    this.body = this.validateObject('body', value, true, properties);
  }

  set _totalAmount(value) {
    this.compareAmounts('amount', value, this.body.amount);
  }
}

export { EdenorPaymentsRequestValidator };
