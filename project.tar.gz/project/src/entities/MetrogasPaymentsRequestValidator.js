import { PaymentsRequestValidator } from './PaymentsRequestValidator';

class MetrogasPaymentsRequestValidator extends PaymentsRequestValidator {
  constructor({ body = null, ...restParameters }) {
    super('MetrogasPaymentsRequestValidator', restParameters);
    this._body = body;
    this._totalAmount = body.totalAmount;
  }

  set _body(value) {
    const properties = {
      invoiceReferenceId: {
        type: this.dataTypes.string,
        pattern: '^[A-Za-z0-9]{14}$',
      },
      payerContractAccountId: {
        type: this.dataTypes.string,
        pattern: '^\\d{11,12}$',
      },
      paymentAmount: {
        type: this.dataTypes.amount,
      },
      paymentFormId: {
        type: this.dataTypes.string,
        pattern: '^\\d{11,12}$',
      },
      documents: {
        type: this.dataTypes.array,
      },
      paymentType: {
        type: this.dataTypes.string,
        pattern: this.paymentTypePattern,
      },
    };

    this.body = this.validateObject('body', value, true, properties);
  }

  set _totalAmount(value) {
    this.compareAmounts('amount', value, this.body.paymentAmount);
  }
}

export { MetrogasPaymentsRequestValidator };
