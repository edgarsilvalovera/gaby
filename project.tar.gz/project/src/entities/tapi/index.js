import { paymentRequestEntity } from './paymentRequestEntity';
import { balanceRequestEntity } from './balanceRequestEntity';
import Validator from '../../helpers/ValidatorHelper';
import { InvalidEntity } from '../../exceptions/InvalidEntity';

const validator = Object.freeze(new Validator());

const tapiPaymentRequestEntity = paymentRequestEntity({
  dependencies: {
    validator,
    InvalidEntity,
  },
});

const tapiBalanceRequestEntity = balanceRequestEntity({
  dependencies: {
    validator,
    InvalidEntity,
  },
});

export { tapiPaymentRequestEntity, tapiBalanceRequestEntity };
