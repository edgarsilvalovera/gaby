import EMU from '../../constants/emu';
const {
  headers: { mainTx: mainTxHeader, accountId: accountIdHeader },
} = EMU;

export const paymentRequestEntity =
  ({ dependencies }) =>
  (params) => {
    const { data = {}, utility, headers = {}, mainTx, accountId = '-' } = params;
    const { validator, InvalidEntity } = dependencies;
    const {
      amount,
      debtId,
      companyCode,
      paymentMethod = 'ACCOUNT',
      operationId = '-',
      expirationDate = '-',
      type = 'service',
      companyName = '-',
    } = data;

    try {
      return Object.freeze({
        data: {
          amount: validator.isValidNumber({ amount }),
          debtId: validator.isValidString({ debtId }),
          companyCode: validator.isValidString({ companyCode }),
          paymentMethod: validator.isValidString({ paymentMethod }),
          operationId: validator.isValidString({ operationId }),
          expirationDate: validator.isValidString({ expirationDate }),
          type: validator.isValidString({ type }),
          companyName: validator.isValidString({ companyName }),
        },
        utility: validator.isValidString({ utility }),
        headers: {
          [mainTxHeader]: validator.isValidString({
            mainTx: mainTx || headers[mainTxHeader] || '-',
          }),
          [accountIdHeader]: validator.isValidString({ accountId }),
        },
      });
    } catch (error) {
      throw new InvalidEntity(error.message);
    }
  };
