import { makeFakeBalanceRequest } from '../../../../__test__/mocks/gateways/tapi/requests/makeFakeRequests';
import { tapiBalanceRequestEntity } from '..';
import { InvalidEntity } from '../../../exceptions/InvalidEntity';

describe('balance request entity', () => {
  it('Should retur validated request', async () => {
    const request = makeFakeBalanceRequest();

    const { data, utility, headers } = tapiBalanceRequestEntity(request);

    expect(Object.keys(data)).toEqual(['companyCode', 'modalityId', 'queryData']);
    expect(utility).toEqual(request.utility);
    expect(Object.keys(headers)).toEqual(['x-main-tx', 'x-account-id']);
  });

  it('Should throw error if  request has invalid fields', async () => {
    const request = makeFakeBalanceRequest({
      data: {
        queryData: null,
        companyCode: null,
        modalityId: null,
      },
    });

    expect(() => tapiBalanceRequestEntity(request)).toThrow(InvalidEntity);
  });
});
