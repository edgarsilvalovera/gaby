import { makeFakePaymentRequest } from '../../../../__test__/mocks/gateways/tapi/requests/makeFakeRequests';
import { tapiPaymentRequestEntity } from '..';
import { InvalidEntity } from '../../../exceptions/InvalidEntity';

describe('payment request entity', () => {
  it('Should retur validated request', async () => {
    const request = makeFakePaymentRequest();

    const { data, utility, headers } = tapiPaymentRequestEntity(request);

    expect(Object.keys(data)).toEqual([
      'amount',
      'debtId',
      'companyCode',
      'paymentMethod',
      'operationId',
      'expirationDate',
      'type',
      'companyName',
    ]);
    expect(utility).toEqual(request.utility);
    expect(Object.keys(headers)).toEqual(['x-main-tx', 'x-account-id']);
  });

  it('Should throw error if  request has invalid fields', async () => {
    const request = makeFakePaymentRequest({
      data: {
        amount: null,
        debtId: null,
        companyCode: null,
        paymentMethod: null,
        operationId: null,
        expirationDate: null,
        type: null,
        companyName: null,
      },
    });

    expect(() => tapiPaymentRequestEntity(request)).toThrow(InvalidEntity);
  });
});
