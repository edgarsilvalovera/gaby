import EMU from '../../constants/emu';
const {
  headers: { mainTx: mainTxHeader, accountId: accountIdHeader },
} = EMU;

export const balanceRequestEntity =
  ({ dependencies }) =>
  (params) => {
    const { data = {}, utility, headers = {}, accountId = '-' } = params;
    const { validator, InvalidEntity } = dependencies;
    const { queryData, modalityId, companyCode } = data;
    try {
      return Object.freeze({
        data: {
          companyCode: validator.isValidString({ companyCode }),
          modalityId: validator.isValidString({ modalityId }),
          queryData: buildQueryData({ queryData, validator }),
        },
        utility: validator.isValidString({ utility }),
        headers: {
          [mainTxHeader]: validator.isValidString({ mainTx: headers[mainTxHeader] || '-' }),
          [accountIdHeader]: validator.isValidString({ accountId }),
        },
      });
    } catch (error) {
      throw new InvalidEntity(error.message);
    }
  };

const buildQueryData = ({ queryData, validator }) => {
  return Object.keys(queryData).map((key) => ({
    name: validator.isValidString({ key }),
    value: validator.isValidString({ value: queryData[key] }),
  }));
};
