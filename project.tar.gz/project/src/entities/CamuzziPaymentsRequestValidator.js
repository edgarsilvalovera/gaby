import { PaymentsRequestValidator } from './PaymentsRequestValidator';

class CamuzziPaymentsRequestValidator extends PaymentsRequestValidator {
  constructor({ body = null, ...restParameters }) {
    super('CamuzziPaymentsRequestValidator', restParameters);
    this._body = body;
    this._totalAmount = body.totalAmount;
  }

  set _body(value) {
    const properties = {
      cuit: {
        type: this.dataTypes.string,
        pattern: '^\\d{11}$',
      },
      accountNumber: {
        type: this.dataTypes.string,
        pattern: '^\\d{17}$',
      },
      amount: {
        type: this.dataTypes.amount,
      },
      invoices: {
        type: this.dataTypes.string,
      },
      paymentType: {
        type: this.dataTypes.string,
        pattern: this.paymentTypePattern,
      },
    };

    this.body = this.validateObject('body', value, true, properties);
  }

  set _totalAmount(value) {
    this.compareAmounts('amount', value, this.body.amount);
  }
}

export { CamuzziPaymentsRequestValidator };
