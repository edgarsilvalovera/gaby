import { PaymentsRequestValidator } from './PaymentsRequestValidator';

class GasnorPaymentsRequestValidator extends PaymentsRequestValidator {
  constructor({ body = null, ...restParameters }) {
    super('GasnorPaymentsRequestValidator', restParameters);
    this._body = body;
    this._totalAmount = body.totalAmount;
  }

  set _body(value) {
    const properties = {
      paymentDocument: {
        type: this.dataTypes.string,
        pattern: '^[A-Za-z0-9 ]+$',
      },
      amount: {
        type: this.dataTypes.amount,
      },
      paymentMethod: {
        type: this.dataTypes.string,
        pattern: this.paymentTypePattern,
      },
      branch: {
        type: this.dataTypes.string,
        pattern: '\\d{4}',
      },
      documentType: {
        type: this.dataTypes.string,
        pattern: '^[A-Za-z0-9 ]{2}',
      },
      dueDate: {
        type: this.dataTypes.string,
      },
    };

    this.body = this.validateObject('body', value, true, properties);
  }

  set _totalAmount(value) {
    this.compareAmounts('amount', value, this.body.amount);
  }
}

export { GasnorPaymentsRequestValidator };
