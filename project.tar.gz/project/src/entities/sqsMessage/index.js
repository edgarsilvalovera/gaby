import sendSqsMessageEntityInstance from './sendSqsMessageEntity';
import Validator from '../../helpers/ValidatorHelper';
import { keysToCamel } from '../../helpers/keyParsers';

const sendSqsMessageEntity = sendSqsMessageEntityInstance({
  dependencies: {
    Validator: new Validator(),
    keysToCamel,
  },
});

export { sendSqsMessageEntity };
