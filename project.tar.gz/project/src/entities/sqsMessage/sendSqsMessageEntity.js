const sendSqsMessageEntity =
  ({ dependencies }) =>
  (params) => {
    const { Validator } = dependencies;
    const {
      delaySeconds = 0,
      messageAttributes = null,
      messageBody = null,
      queueUrl = null,
    } = params;

    return Object.freeze({
      delaySeconds: Validator.isValidNumber({ delaySeconds }),
      messageAttributes: messageAttributes ? Validator.isValidString({ messageAttributes }) : null,
      messageBody: Validator.isValidString({ messageBody }),
      queueUrl: Validator.isValidString({ queueUrl }),
    });
  };

export default sendSqsMessageEntity;
