import { BaseEntity } from './BaseEntity';
import EMU from '../constants/emu';

const {
  qrTypes: { iep },
  headers: { mainTx, accountId },
} = EMU;

class BalancesRequestValidator extends BaseEntity {
  constructor({
    utility = null,
    baseURL = null,
    headers = null,
    urlParams = null,
    queryParams = null,
  }) {
    super('BalancesRequestValidator');

    this._queryParams = queryParams;
    this.isInteroperable = this.queryParams.qrType === iep;

    this._urlParams = urlParams;
    this._headers = headers;
    this._baseURL = baseURL;
    this._utility = utility;
  }

  set _queryParams(value) {
    const properties = {
      qrType: {
        type: this.dataTypes.string,
        pattern: '^(?:iep|service)$',
      },
      cuit: {
        type: this.dataTypes.string,
        pattern: '^\\d{11}$',
      },
      additionalInfo: {
        type: this.dataTypes.string,
        required: false,
      },
    };

    this.queryParams = this.validateObject('queryParams', value, true, properties);
  }

  set _urlParams(value) {
    const properties = {
      document: {
        type: this.dataTypes.string,
        pattern: '^[A-Za-z0-9 ]+$',
      },
    };

    this.urlParams = this.validateObject('urlParams', value, true, properties);
  }

  set _headers(value) {
    const properties = {
      [mainTx]: {
        type: this.dataTypes.uuid,
      },
      [accountId]: {
        type: this.dataTypes.uuid,
        required: !this.isInteroperable,
      },
    };

    this.headers = this.validateObject('headers', value, true, properties);
  }

  set _baseURL(value) {
    this.baseURL = this.validateURL('baseURL', value, true);
  }

  set _utility(value) {
    this.utility = this.validateString('utility', value, true, '^[A-Za-z][\\w|\\-|\\.| ]+$');
  }
}

export { BalancesRequestValidator };
