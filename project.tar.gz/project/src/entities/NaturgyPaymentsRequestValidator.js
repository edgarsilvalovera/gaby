import { PaymentsRequestValidator } from './PaymentsRequestValidator';

class NaturgyPaymentsRequestValidator extends PaymentsRequestValidator {
  constructor({ body = null, ...restParameters }) {
    super('NaturgyPaymentsRequestValidator', restParameters);
    this._body = body;
    this._totalAmount = body.totalAmount;
  }

  set _body(value) {
    const properties = {
      paymentDocument: {
        type: this.dataTypes.number,
      },
      amount: {
        type: this.dataTypes.amount,
      },
      paymentMethod: {
        type: this.dataTypes.string,
        pattern: this.paymentTypePattern,
      },
      clientId: {
        type: this.dataTypes.string,
        pattern: '\\d{7}',
      },
      documentType: {
        type: this.dataTypes.string,
        pattern: '\\w{1,2}',
      },
      concept: {
        type: this.dataTypes.string,
        pattern: '\\w{1,2}',
      },
      year: {
        type: this.dataTypes.number,
      },
      bimester: {
        type: this.dataTypes.number,
      },
      semiVoucher: {
        type: this.dataTypes.number,
        zero: true,
      },
    };

    this.body = this.validateObject('body', value, true, properties);
  }

  set _totalAmount(value) {
    this.compareAmounts('amount', value, this.body.amount);
  }
}

export { NaturgyPaymentsRequestValidator };
