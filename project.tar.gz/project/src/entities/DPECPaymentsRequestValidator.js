import { PaymentsRequestValidator } from './PaymentsRequestValidator';

class DPECPaymentsRequestValidator extends PaymentsRequestValidator {
  constructor({ body = null, ...restParameters }) {
    super('DPECPaymentsRequestValidator', restParameters);
    this._body = body;
    this._totalAmount = body.totalAmount;
  }

  set _body(value) {
    const properties = {
      paymentDocument: {
        type: this.dataTypes.string,
        pattern: '\\d{10}',
      },
      amount: {
        type: this.dataTypes.amount,
      },
      paymentMethod: {
        type: this.dataTypes.string,
        pattern: this.paymentTypePattern,
      },
      barCode: {
        type: this.dataTypes.string,
        pattern: '^\\d{30}',
      },
      paymentReference: {
        type: this.dataTypes.string,
        pattern: '^\\d{1,20}',
      },
    };

    this.body = this.validateObject('body', value, true, properties);
  }

  set _totalAmount(value) {
    this.compareAmounts('amount', value, this.body.amount);
  }
}

export { DPECPaymentsRequestValidator };
