import { TapError } from './TapError';

class PostgresFailedUpdate extends TapError {
  constructor() {
    super({
      message: 'SQL UPDATE statement failed in Postgres',
      code: 'UT07131',
    });
  }
}

export { PostgresFailedUpdate };
