import { BAD_REQUEST } from 'http-status';
import { TapError } from './TapError';

class OASpecBadRequest extends TapError {
  constructor() {
    super({
      message: 'Bad request from Open API Specification',
      code: 'UT84000',
      status: BAD_REQUEST,
    });
  }
}

export { OASpecBadRequest };
