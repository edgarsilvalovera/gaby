import { TapError } from './TapError';

class UtilityBalancesError extends TapError {
  constructor(error) {
    super(error);
  }
}

export { UtilityBalancesError };
