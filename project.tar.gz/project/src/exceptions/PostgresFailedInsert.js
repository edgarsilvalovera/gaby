import { TapError } from './TapError';

class PostgresFailedInsert extends TapError {
  constructor() {
    super({
      message: 'SQL INSERT statement failed in Postgres',
      code: 'UT07111',
    });
  }
}

export { PostgresFailedInsert };
