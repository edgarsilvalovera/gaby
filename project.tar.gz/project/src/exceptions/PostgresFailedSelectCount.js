import { TapError } from './TapError';

class PostgresFailedSelectCount extends TapError {
  constructor() {
    super({
      message: 'SQL SELECT COUNT statement failed in Postgres',
      code: 'UT07122',
    });
  }
}

export { PostgresFailedSelectCount };
