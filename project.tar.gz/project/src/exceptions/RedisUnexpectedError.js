import { TapError } from './TapError';

class RedisUnexpectedError extends TapError {
  constructor() {
    super({
      message: 'Unexpected error on Redis',
      code: 'UT07299',
    });
  }
}

export { RedisUnexpectedError };
