import { TapError } from './TapError';

class UtilityPaymentsError extends TapError {
  constructor(error) {
    super(error);
  }
}

export { UtilityPaymentsError };
