import { TapError } from './TapError';

class PostgresFailedSelect extends TapError {
  constructor() {
    super({
      message: 'SQL SELECT statement failed in Postgres',
      code: 'UT07121',
    });
  }
}

export { PostgresFailedSelect };
