import { INTERNAL_SERVER_ERROR } from 'http-status';

// internal server error in tap (base exception class)
class TapError extends Error {
  constructor({
    message = 'Unknown error',
    code = 'UT05000',
    status = INTERNAL_SERVER_ERROR,
  } = {}) {
    super(message);
    this.code = code;
    this.status = status;
  }
}

export { TapError };
