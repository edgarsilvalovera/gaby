import { INTERNAL_SERVER_ERROR } from 'http-status';
import { TapError } from './TapError';

class OASpecBadResponse extends TapError {
  constructor() {
    super({
      message: 'Bad response from Open API Specification',
      code: 'UT85000',
      status: INTERNAL_SERVER_ERROR,
    });
  }
}

export { OASpecBadResponse };
