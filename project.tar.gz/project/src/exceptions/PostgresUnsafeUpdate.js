import { TapError } from './TapError';

class PostgresUnsafeUpdate extends TapError {
  constructor() {
    super({
      message: 'SQL UPDATE statement without WHERE clause in Postgres',
      code: 'UT07139',
    });
  }
}

export { PostgresUnsafeUpdate };
