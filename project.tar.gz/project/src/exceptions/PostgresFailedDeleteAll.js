import { TapError } from './TapError';

class PostgresFailedDeleteAll extends TapError {
  constructor() {
    super({
      message: 'SQL DELETE (all) statement failed in Postgres',
      code: 'UT07141',
    });
  }
}

export { PostgresFailedDeleteAll };
