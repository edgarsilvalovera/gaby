import { TapError } from './TapError';

class PostgresFailedDeleteWhere extends TapError {
  constructor() {
    super({
      message: 'SQL DELETE (WHERE clause) statement failed in Postgres',
      code: 'UT07142',
    });
  }
}

export { PostgresFailedDeleteWhere };
