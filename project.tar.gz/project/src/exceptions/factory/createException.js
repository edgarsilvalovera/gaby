import { UNAUTHORIZED, INTERNAL_SERVER_ERROR } from 'http-status';
import * as exceptions from '../';

// mapping of services-exceptions
const mappedExceptions = {
  balances: exceptions.UtilityBalancesError,
  payments: exceptions.UtilityPaymentsError,
};

const createException = (service, utility, error) => {
  const { request, response } = error;

  // unexpected error
  let Exception = exceptions.TapError;

  if (response) {
    const { data, status } = response;

    if (status === UNAUTHORIZED) {
      Exception = exceptions.UtilityUnauthorizedAccess.bind(null, utility);
    } else if (status === INTERNAL_SERVER_ERROR) {
      Exception = exceptions.UtilityInternalServerError.bind(null, utility);
    } else {
      const serviceException = mappedExceptions[service] || null;

      if (serviceException) {
        Exception = serviceException.bind(null, { ...data, status });
      } else {
        Exception = exceptions.UnknownService.bind(null, service);
      }
    }
  } else if (request) {
    // no response
    Exception = exceptions.UtilityServiceUnavailable.bind(null, utility);
  }
  return new Exception();
};

export default createException;
