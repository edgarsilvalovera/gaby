import { UNAUTHORIZED } from 'http-status';
import { TapError } from './TapError';

class OASpecUnauthorized extends TapError {
  constructor() {
    super({
      message: 'Unauthorized from Open API Specification',
      code: 'UT84010',
      status: UNAUTHORIZED,
    });
  }
}

export { OASpecUnauthorized };
