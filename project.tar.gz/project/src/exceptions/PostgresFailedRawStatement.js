import { TapError } from './TapError';

class PostgresFailedRawStatement extends TapError {
  constructor() {
    super({
      message: 'SQL (raw) statement failed in Postgres',
      code: 'UT07100',
    });
  }
}

export { PostgresFailedRawStatement };
