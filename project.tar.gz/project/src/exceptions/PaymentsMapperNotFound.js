import { NOT_FOUND } from 'http-status';
import { TapError } from './TapError';

class PaymentsMapperNotFound extends TapError {
  constructor(parser) {
    super({
      message: `Utility (${parser}) payments mapper not found`,
      code: 'UT34041',
      status: NOT_FOUND,
    });
  }
}

export { PaymentsMapperNotFound };
