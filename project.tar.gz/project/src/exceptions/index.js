export { TapError } from './TapError';

export { OASpecBadRequest } from './OASpecBadRequest';
export { OASpecUnauthorized } from './OASpecUnauthorized';
export { OASpecForbidden } from './OASpecForbidden';
export { OASpecNotFound } from './OASpecNotFound';
export { OASpecBadResponse } from './OASpecBadResponse';

export { UtilityNotFound } from './UtilityNotFound';
export { UnknownService } from './UnknownService';

export { PostgresFailedInsert } from './PostgresFailedInsert';
export { PostgresFailedSelect } from './PostgresFailedSelect';
export { PostgresFailedSelectCount } from './PostgresFailedSelectCount';
export { PostgresUnsafeUpdate } from './PostgresUnsafeUpdate';
export { PostgresFailedUpdate } from './PostgresFailedUpdate';
export { PostgresFailedUpdateIn } from './PostgresFailedUpdateIn';
export { PostgresUnsafeDelete } from './PostgresUnsafeDelete';
export { PostgresFailedDeleteAll } from './PostgresFailedDeleteAll';
export { PostgresFailedDeleteWhere } from './PostgresFailedDeleteWhere';
export { PostgresFailedRawStatement } from './PostgresFailedRawStatement';

export { RedisFailedSetter } from './RedisFailedSetter';
export { RedisFailedGetter } from './RedisFailedGetter';
export { RedisUnexpectedError } from './RedisUnexpectedError';

export { InvalidEntity } from './InvalidEntity';

export { BalancesMapperNotFound } from './BalancesMapperNotFound';
export { CachedBalanceNotFound } from './CachedBalanceNotFound';

export { PaymentsMapperNotFound } from './PaymentsMapperNotFound';
export { PaymentEntityNotFound } from './PaymentEntityNotFound';

export { UtilityUnauthorizedAccess } from './UtilityUnauthorizedAccess';
export { UtilityInternalServerError } from './UtilityInternalServerError';
export { UtilityServiceUnavailable } from './UtilityServiceUnavailable';

export { UtilityBalancesError } from './UtilityBalancesError';
export { UtilityPaymentsError } from './UtilityPaymentsError';
