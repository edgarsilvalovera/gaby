import { TapError } from './TapError';

class RedisFailedSetter extends TapError {
  constructor() {
    super({
      message: 'Error setting a key on Redis',
      code: 'UT07211',
    });
  }
}

export { RedisFailedSetter };
