import { SERVICE_UNAVAILABLE } from 'http-status';
import { TapError } from './TapError';

class UtilityServiceUnavailable extends TapError {
  constructor(utility) {
    super({
      message: `No response from MS-${utility}`,
      code: 'UT95030',
      status: SERVICE_UNAVAILABLE,
    });
  }
}

export { UtilityServiceUnavailable };
