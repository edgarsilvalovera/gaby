import { TapError } from './TapError';

class RedisFailedGetter extends TapError {
  constructor() {
    super({
      message: 'Error getting a key from Redis',
      code: 'UT07221',
    });
  }
}

export { RedisFailedGetter };
