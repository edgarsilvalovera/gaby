import { NOT_FOUND } from 'http-status';
import { TapError } from './TapError';

class UtilityNotFound extends TapError {
  constructor() {
    super({
      message: 'Utility not found',
      code: 'UT04040',
      status: NOT_FOUND,
    });
  }
}

export { UtilityNotFound };
