import { NOT_FOUND } from 'http-status';
import { TapError } from './TapError';

class CachedBalanceNotFound extends TapError {
  constructor() {
    super({
      message: 'Cached balance not found',
      code: 'UT24042',
      status: NOT_FOUND,
    });
  }
}

export { CachedBalanceNotFound };
