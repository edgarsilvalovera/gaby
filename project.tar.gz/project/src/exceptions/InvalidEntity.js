import { BAD_REQUEST } from 'http-status';
import { TapError } from './TapError';

class InvalidEntity extends TapError {
  constructor(message) {
    super({
      message,
      code: 'UT04000',
      status: BAD_REQUEST,
    });
  }
}

export { InvalidEntity };
