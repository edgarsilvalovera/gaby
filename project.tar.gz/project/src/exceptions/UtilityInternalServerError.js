import { INTERNAL_SERVER_ERROR } from 'http-status';
import { TapError } from './TapError';

class UtilityInternalServerError extends TapError {
  constructor(utility) {
    super({
      message: `Unexpected error in MS-${utility}`,
      code: 'UT95000',
      status: INTERNAL_SERVER_ERROR,
    });
  }
}

export { UtilityInternalServerError };
