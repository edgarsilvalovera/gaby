import { TapError } from './TapError';

class PostgresUnsafeDelete extends TapError {
  constructor() {
    super({
      message: 'SQL DELETE statement without WHERE clause in Postgres',
      code: 'UT07149',
    });
  }
}

export { PostgresUnsafeDelete };
