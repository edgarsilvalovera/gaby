import { FORBIDDEN } from 'http-status';
import { TapError } from './TapError';
import EMU from '../constants/emu';

const {
  headers: { mainTx, accountId },
} = EMU;

const mappedHeaders = {
  [mainTx]: 1,
  [accountId]: 2,
};

class OASpecForbidden extends TapError {
  constructor(header) {
    super({
      message: 'Forbidden from Open API Specification',
      code: `UT8403${mappedHeaders[header]}`,
      status: FORBIDDEN,
    });
  }
}

export { OASpecForbidden };
