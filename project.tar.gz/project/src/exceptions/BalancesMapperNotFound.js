import { NOT_FOUND } from 'http-status';
import { TapError } from './TapError';

class BalancesMapperNotFound extends TapError {
  constructor() {
    super({
      message: 'Utility balances mapper not found',
      code: 'UT24041',
      status: NOT_FOUND,
    });
  }
}

export { BalancesMapperNotFound };
