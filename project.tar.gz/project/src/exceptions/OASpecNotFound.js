import { NOT_FOUND } from 'http-status';
import { TapError } from './TapError';

class OASpecNotFound extends TapError {
  constructor() {
    super({
      message: 'Not found from Open API Specification',
      code: 'UT84040',
      status: NOT_FOUND,
    });
  }
}

export { OASpecNotFound };
