import { NOT_FOUND } from 'http-status';
import { TapError } from './TapError';

class PaymentEntityNotFound extends TapError {
  constructor() {
    super({
      message: 'Payment entity not found',
      code: 'UT34042',
      status: NOT_FOUND,
    });
  }
}

export { PaymentEntityNotFound };
