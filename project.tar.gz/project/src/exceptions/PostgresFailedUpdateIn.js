import { TapError } from './TapError';

class PostgresFailedUpdateIn extends TapError {
  constructor() {
    super({
      message: 'SQL UPDATE (IN filter) statement failed in Postgres',
      code: 'UT07132',
    });
  }
}

export { PostgresFailedUpdateIn };
