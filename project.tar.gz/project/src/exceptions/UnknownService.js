import { BAD_GATEWAY } from 'http-status';
import { TapError } from './TapError';

class UnknownService extends TapError {
  constructor(service) {
    super({
      message: `Unknown service: ${service}`,
      code: 'UT05020',
      status: BAD_GATEWAY,
    });
  }
}

export { UnknownService };
