import { TapError } from './TapError';

class RedisFailedParser extends TapError {
  constructor() {
    super({
      message: 'Parser error on Redis',
      code: 'UT07200',
    });
  }
}

export { RedisFailedParser };
