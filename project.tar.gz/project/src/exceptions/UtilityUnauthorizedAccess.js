import { UNAUTHORIZED } from 'http-status';
import { TapError } from './TapError';

class UtilityUnauthorizedAccess extends TapError {
  constructor(utility) {
    super({
      message: `Unauthorized request by MS-${utility}`,
      code: 'UT94010',
      status: UNAUTHORIZED,
    });
  }
}

export { UtilityUnauthorizedAccess };
