class ErrorResponse {
  constructor(code, message) {
    this.code = code;
    this._message = message;
  }

  set _message(value) {
    this.message = !value.includes(`${this.code}: `) ? `${this.code}: ${value}` : value;
  }
}

export { ErrorResponse };
