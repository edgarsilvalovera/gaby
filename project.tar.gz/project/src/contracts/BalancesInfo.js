import * as uuid from 'uuid';
import { BalancesDetail } from './';

// header information of balances (response from the utility's microservice)
class BalancesInfo {
  constructor({ data, mapper }) {
    const {
      msResponse,
      paymentDocument,
      customerName,
      customerAddress,
      balances,
      balancesDetail: { amount, isPayable, concept, message, dueDate },
    } = mapper;

    // due to different responses from microservices
    const dataBalances = data[msResponse] || data;

    this.utility = data.utility;
    this.searchId = uuid.v4();
    this.paymentDocument = dataBalances[paymentDocument];
    this.customerName = dataBalances[customerName] || null;
    this.customerAddress = dataBalances[customerAddress] || null;
    this.balances = dataBalances[balances].map(
      (balance, index) =>
        new BalancesDetail({
          amount: +balance[amount],
          isPayable: balance[isPayable] !== undefined ? balance[isPayable] : true,
          concept: balance[concept] || 'total',
          message: balance[message] || null,
          dueDate: balance[dueDate] || null,
          index,
        }),
    );
  }
}

export { BalancesInfo };
