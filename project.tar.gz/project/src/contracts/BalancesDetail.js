import * as uuid from 'uuid';

// balances breakdown (response from the utility's microservice)
class BalancesDetail {
  constructor({ amount, isPayable, concept, message, dueDate, index }) {
    this.balanceId = uuid.v4();
    this.amount = amount;
    this.isPayable = isPayable;
    this.concept = concept;
    this.message = message;
    this.dueDate = dueDate;
    this.index = index;
  }
}

export { BalancesDetail };
