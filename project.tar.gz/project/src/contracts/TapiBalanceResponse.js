import * as uuid from 'uuid';
import { BalancesDetail } from './BalancesDetail';

// successful response of balances from the utility's microservice
class TapiBalanceResponse {
  constructor({ data }) {
    const { mainTx, tx } = data;

    this.mainTx = mainTx;
    this.tx = tx;
    this.balancesInfo = new TapiBalanceInfo({ data });
  }
}

class TapiBalanceInfo {
  constructor({ data }) {
    const {
      customer: { name = '', address = '' },
      debts,
      operationId,
    } = data;

    this.utility = data.utility;
    this.searchId = uuid.v4();
    this.paymentDocument = operationId;
    this.customerName = name;
    this.customerAddress = address;
    this.balances = debts.map(
      (balance, index) =>
        new BalancesDetail({
          amount: balance.amount,
          isPayable: true,
          dueDate: balance.expirationDate || null,
          index,
        }),
    );
  }
}

export { TapiBalanceResponse, TapiBalanceInfo };
