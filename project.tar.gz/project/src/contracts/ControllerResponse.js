class ControllerResponse {
  constructor(response, status) {
    this.response = response;
    this.status = status;
  }
}

export { ControllerResponse };
