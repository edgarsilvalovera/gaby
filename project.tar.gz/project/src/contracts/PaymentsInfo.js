// header information of payments (response from the utility's microservice)
class PaymentsInfo {
  constructor({ data, mapper }) {
    const { msResponse, paymentId, transactionId, message, code } = mapper;

    // due to different responses from microservices
    const dataPayments = data[msResponse] || data;

    this.paymentId = dataPayments[paymentId];
    this.transactionId = dataPayments[transactionId];
    this.message = dataPayments[message] || null;
    this.code = dataPayments[code] || null;
  }
}

export { PaymentsInfo };
