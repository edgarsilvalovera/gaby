import { PaymentsInfo } from './';

// successful response of payments from the utility's microservice
class PaymentsResponse {
  constructor({ data, mapper }) {
    const { mainTx, tx, ...restData } = data;

    this.mainTx = mainTx;
    this.tx = tx;
    this.paymentsInfo = new PaymentsInfo({ data: restData, mapper });
  }
}

export { PaymentsResponse };
