import { BalancesInfo } from './';

// successful response of balances from the utility's microservice
class BalancesResponse {
  constructor({ data, mapper }) {
    const { mainTx, tx } = data;

    this.mainTx = mainTx;
    this.tx = tx;
    this.balancesInfo = new BalancesInfo({ data, mapper });
  }
}

export { BalancesResponse };
