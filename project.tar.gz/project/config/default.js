import dotenv from 'dotenv';

dotenv.config();

const config = Object.freeze({
  name: 'emu',
  region: 'us-east-1',
  publicPort: process.env.PUBLIC_PORT || 8080,
  privatePort: process.env.PRIVATE_PORT || 8624,
  redis: {
    host: process.env.REDIS_HOST || '127.0.0.1',
    port: process.env.REDIS_PORT || 6379,
  },
  fiatQueueURL:
    process.env.FIAT_QUEUE_URL ||
    'https://sqs.us-east-2.amazonaws.com/009364961040/utility-confirma-debito-queue',
  tapi: {
    baseURL:
      process.env.TAPI_URL ||
      'http://services-gateway.internal.us-east-2-backend.sandbox.auntap.io:8080',
  },
});

export { config };
