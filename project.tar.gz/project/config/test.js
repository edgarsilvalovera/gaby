import dotenv from 'dotenv';

dotenv.config();

const config = Object.freeze({
  name: 'emu',
  region: 'us-east-1',
  publicPort: process.env.PUBLIC_PORT || 8082,
  privatePort: process.env.PRIVATE_PORT || 8624,
  redis: {
    host: process.env.REDIS_HOST || '127.0.0.1',
    port: process.env.REDIS_PORT || 6379,
  },
  fiatQueueURL:
    process.env.FIAT_QUEUE_URL ||
    'https://sqs.us-east-2.amazonaws.com/009364961040/utility-confirma-debito-queue',
  env: 'test',
  sqsTestEndpoint: 'http://localhost:4566',
});

export { config };
