import dotenv from 'dotenv';

dotenv.config();

const config = Object.freeze({
  name: 'emu',
  region: 'us-east-1',
  publicPort: process.env.PUBLIC_PORT,
  privatePort: process.env.PRIVATE_PORT,
  redis: {
    host: process.env.REDIS_HOST,
    port: process.env.REDIS_PORT,
  },
  fiatQueueURL:
    process.env.FIAT_QUEUE_URL ||
    'https://sqs.us-east-2.amazonaws.com/009364961040/utility-confirma-debito-queue',
});

export { config };
