import dotenv from 'dotenv';

dotenv.config();

const client = 'postgres';
const defaultHost = 'localhost';
const defaultUser = 'postgres';

const config = {
  develop: {
    client,
    connection: {
      host: process.env.DB_HOST || defaultHost,
      user: process.env.DB_USER || defaultUser,
      password: process.env.DB_PASSWORD || 'MySdwQsVDw5QffPtHOyYWBZV3B',      
      database: process.env.DB_NAME || 'emu',      
      port: process.env.DB_PORT || 54320,      
    },
  },
  test: {
    client,
    connection: {
      host: defaultHost,
      user: process.env.DB_TEST_USER || defaultUser,
      password: process.env.DB_TEST_PASSWORD || 'tap',
      database: process.env.DB_TEST_NAME || 'test_emu',
      port: 5432,
    },
  },
  production: {
    client,
    connection: {
      host: process.env.DB_HOST,
      user: process.env.DB_USER,
      password: process.env.DB_PASSWORD,
      database: process.env.DB_NAME,
      port: process.env.DB_PORT,
    },
  },
  pool: {
    min: process.env.MIN_POOL_CONNECTIONS || 10,
    max: process.env.MAX_POOL_CONNECTIONS || 1000,
  },
  acquireConnectionTimeout: process.env.CONNECTION_TIMEOUT || 30000,
};

export default config;
