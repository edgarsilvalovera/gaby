alter table public.utilities drop column if exists company_code;
alter table public.utilities drop column if exists tapi_up;
