alter table public.utilities add column if not exists company_code varchar(10);
alter table public.utilities add column if not exists tapi_up boolean;
