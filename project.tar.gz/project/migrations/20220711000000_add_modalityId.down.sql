alter table public.utilities drop column if exists modality_id;
