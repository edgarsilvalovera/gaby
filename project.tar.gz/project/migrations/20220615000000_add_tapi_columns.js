module.exports = require('knex-migrate-sql-file')();
