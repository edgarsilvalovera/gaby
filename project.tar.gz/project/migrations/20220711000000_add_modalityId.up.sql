alter table public.utilities add column if not exists modality_id varchar(40);
