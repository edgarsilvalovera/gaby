create table if not exists public.utilities (
  cuit varchar(11) primary key,
  name varchar(20) not null,
  base_url varchar(255) not null,
  created_at timestamptz(0) not null default current_timestamp
);
