module.exports = {
  coveragePathIgnorePatterns: [
    '/node_modules/',
    './src/constants',
    './__test__',
    './config',
    './knexfile.js',
    './logger',
  ],
  verbose: true,
};
